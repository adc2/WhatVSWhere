%{
Fig. S12 of WW paper.
%}
if ~check_required; return; end

disp('SEEG, BST Utah workshop')
clear

load ../from_bst/electrode_positions_epilepsy_UTAH

fnames={
    '../brainstorm/brainstorm data/workshopUTAH_raw/Baseline.edf',
    '../brainstorm/brainstorm data/workshopUTAH_raw/ictal_repetitive_spike.edf',
    '../brainstorm/brainstorm data/workshopUTAH_raw/interictal_spike.edf',
    '../brainstorm/brainstorm data/workshopUTAH_raw/LVFA_and_wave.edf'};
    
fname=fnames{3};
h=ft_read_header(fname);
sr=h.Fs;
x=ft_read_data(fname);
x=x';


idxSEEG=find(count(h.label,'SEEG')&~count(h.label, 'SEEG_NO_LOC'));
% a=idxSEEG;
% a([203    98   204 ])=[];
%idxSEEG=a;
labels=h.label(idxSEEG);
x=x(:,idxSEEG);
t=linspace(-5, 5, size(x,1));

% remove mean
x=nt_demean(x);


% remove power artifacts
nremove=3;
x=nt_zapline(x,60/sr,nremove);

% high-pass
hpf=200; % Hz
[b,a]=butter(2,hpf/(sr/2),'high');
x=filter(b,a,x);

% clip glitches
x=x(201:end-200,:);
t=t(201:end-200);
x=nt_demean(x);

if 0
    y=nt_sns(x,10);
    for iChannel=1:size(x,2)
        a=x(:,iChannel)-y(:,iChannel);
        thresh=3*std(a);
        a=min(a,thresh);
        a=max(a,-thresh);
        x(:,iChannel)=y(:,iChannel)+a;
    end
end

figure(1); clf
plot(t,x);

% SCA
nscs=50;
toscs=nt_sca(x);
xx=x*toscs(:,1:nscs);

% first DSS: loose focus
c0=nt_cov(xx(t<-0.2,:));
c1=nt_cov(xx(t>-0.2,:));
[todss1,pwr0,pwr1]=nt_dss0(c0,c1);
figure(2); clf;
plot(pwr1./pwr0,'.-')
z=xx*todss1;
figure(3); clf; plot(t,z(:,1:3)); %xlim([-0.1 0.1])
ndss=20;
z=z(:,1:ndss);

% second DSS: tight focus
c0=nt_cov(z);
c1=nt_cov(z(t>-0.1&t<-0.02,:));
[todss2,pwr0,pwr1]=nt_dss0(c0,c1);
figure(4); clf;
plot(pwr1./pwr0,'.-')
zz=z*todss2;
figure(5); clf; plot(t,zz(:,1:2)); xlim([-0.2 0.1])

% correlation with each electrode
activations=nt_xcov(nt_normcol(zz(:,1)),nt_normcol(x));
activations=sum(abs(activations),1);
[~,idxBest]=sort(activations, 'descend');

drawnow

switch 2
    case 1
        F=[toscs(:,1:nscs)*todss1(:,1:ndss)*todss2, toscs(:,1:nscs)*todss1(:,ndss+1:end),toscs(:,nscs+1:end)];
    case 2
        F=[toscs(:,1:nscs)*todss1(:,1:ndss)*todss2, toscs(:,1:nscs)*todss1(:,ndss+1:end)];
    case 3
        F=[toscs(:,1:nscs)*todss1(:,1:ndss)*todss2];
end


F=nt_normcol(F);

load ../from_bst/head_model_workshopUTAH_volume_2mm
loc=head_model.GridLoc;
orient=head_model.GridOrient;
g=head_model.Gain(idxSEEG,:);
nlocations=size(g,2)/3;
nsensors=size(g,1);
g=g'; % --> (nlocationsX3) X nsensors
g=reshape(g,3,nlocations,nsensors);
g=permute(g,[2,3,1]);
x=loc(:,1);
y=loc(:,2);
z=loc(:,3);

% NKEEP=100;
% F=F(idxBest(1:NKEEP),:);
% g=g(:,idxBest(1:NKEEP),:);
% 
nTarget=2;
[~,~,~,cc]=find_source_orient(nt_mmat(g,F),nTarget);
cc=log10(cc);
cc=cc-max(cc);

figure(6); clf;
set(gcf,'position',[200   597   1200   400])
plot_cost_volume(cc,loc,[],electrode_positions);


figure(7); clf;
set(gcf,'position',[200   597   1200   400])
markersize=150;
plot_cost_volume(cc,loc,[-50,-0;-50,0;40,90],electrode_positions,markersize,activations);


