%{
Fig. S11 of WW paper.
%}
if ~check_required; return; end

clear
%rng(0)

% load head model & data
if 1
    switch 2
        case 1
            load ../from_bst/head_model_MEG_sample_introduction_run1_volume_2mm
            D=read_brainstorm_tutorial_data('MEG_sample_introduction_run1');
        case 2
            load ./from_bst/head_model_MEG_sample_introduction_run2_volume_2mm
            D=read_brainstorm_tutorial_data('MEG_sample_introduction_run2');
    end
    save ../tmp/tmp_Fig_S10 head_model D
else
    load ../tmp/tmp_Fig_S10
end


nt_whoss;
[gain3,gain,locations,orientations]=headmodelparse(head_model); 

% all locations?
idxLocationsL=find(locations(:,2)>=0);
idxLocationsR=find(locations(:,2)<=0);

meg=cat(3,D.s,D.d); 
meg=D.s; 

% all sensors?
idxGrad=1:274; % guess based on lables
idxSensorsL=find(D.h.grad.chanpos(idxGrad,2)>=0);
idxSensorsR=find(D.h.grad.chanpos(idxGrad,2)<=0);

if 0
    % filter?
    meg=nt_demean2(meg,1:120);
    [B,A]=butter(2,1/(D.sr/2),'high');
    meg=filter(B,A,meg);
    [B,A]=butter(2,20/(D.sr/2),'low');
    %s=filter(B,A,s);
end

% suppress outlier trials
idx=nt_find_outlier_trials(meg,2.5);
meg=meg(:,:,idx);


figure(1); clf
set(gcf,'position',[200   597   1200   200])
background=[1 1 1]*1;


% auditory, left hemisphere
m=meg(:,idxSensorsL,:);
g3=gain3(idxLocationsL,idxSensorsL,:);
l=locations(idxLocationsL,:);
x=l(:,1);
y=l(:,2);
z=l(:,3);

% SCA
toscs=nt_sca(m);
NSCS=100;

% DSS
FOCUS=1:200; % 330 ms
[todss,pwr0,pwr1]=nt_dss1(nt_mmat(m(FOCUS,:,:),toscs(:,1:NSCS)));
if 0
    figure(1); clf;
    plot(pwr1./pwr0, '.-');
end

F=toscs(:,1:NSCS)*todss;
if 1
    %F=F(:,1:30);
    F=nt_normcol(F);
end
%GSF=g*F;

nTarget=1;
[~,~,~,cc]=find_source_orient(nt_mmat(g3,F),nTarget);
cc=log10(cc);

h1=subplot(151);
[cc_collapsed,l_collapsed]=collapse_xyz(cc,l,2);
x=l_collapsed(:,1);
y=l_collapsed(:,2);
z=l_collapsed(:,3);
scatter3(x,y,z,10,cc_collapsed,'filled');

colormap (h1, parula);
h=colorbar('southoutside');
set(h,'fontsize',14);
set(get(h,'label'),'string','$log_{10}$(cost)','interpreter','latex', 'fontsize',18);
set(gca,'color',[1 1 1])
set(gca,'xtick',[],'ytick',[],'ztick',[]);
set(gca,'box','off')
set(get(gca,'xaxis'), 'visible','off')
set(get(gca,'yaxis'), 'visible','off')
set(get(gca,'zaxis'), 'visible','off')
colormap(h1,parula);
set(gca,'clim',[-inf 0]);
view(180, 0);
drawnow


% auditory, right hemisphere
m=meg(:,idxSensorsR,:);
g3=gain3(idxLocationsR,idxSensorsR,:);
l=locations(idxLocationsR,:);
x=l(:,1);
y=l(:,2);
z=l(:,3);

% SCA
toscs=nt_sca(m);
NSCS=100;

% DSS
FOCUS=1:200; % 330 ms
[todss,pwr0,pwr1]=nt_dss1(nt_mmat(m(FOCUS,:,:),toscs(:,1:NSCS)));
if 0
    figure(1); clf;
    plot(pwr1./pwr0, '.-');
end

F=toscs(:,1:NSCS)*todss;
if 1
    %F=F(:,1:20);
    F=nt_normcol(F);
end
%GSF=g*F;

nTarget=1;
[~,~,~,cc]=find_source_orient(nt_mmat(g3,F),nTarget);
cc=log10(cc);

h2=subplot(152);
[cc_collapsed,l_collapsed]=collapse_xyz(cc,l,2);
x=l_collapsed(:,1);
y=l_collapsed(:,2);
z=l_collapsed(:,3);
scatter3(x,y,z,10,cc_collapsed,'filled');
colormap (h1, parula);
h=colorbar('southoutside');
set(h,'fontsize',14);
set(get(h,'label'),'string','$log_{10}$(cost)','interpreter','latex', 'fontsize',18);
set(gca,'color',[1 1 1])
set(gca,'xtick',[],'ytick',[],'ztick',[]);
set(gca,'box','off')
set(get(gca,'xaxis'), 'visible','off')
set(get(gca,'yaxis'), 'visible','off')
set(get(gca,'zaxis'), 'visible','off')
colormap(h2,parula);
set(gca,'clim',[-inf 0]);
view(0, 0);
drawnow

% button press
meg=D.b;

if 0
    % filter?
    meg=nt_demean2(meg,1:120);
    [B,A]=butter(2,1/(D.sr/2),'high');
    meg=filter(B,A,meg);
    [B,A]=butter(2,20/(D.sr/2),'low');
    %s=filter(B,A,s);
end

m=meg;
g3=gain3;
l=locations;
x=l(:,1);
y=l(:,2);
z=l(:,3);

% SCA
toscs=nt_sca(m);
NSCS=100;

% DSS
FOCUS=301:600; % % 500ms before press
[todss,pwr0,pwr1]=nt_dss1(nt_mmat(m(FOCUS,:,:),toscs(:,1:NSCS)));
if 0
    figure(1); clf;
    plot(pwr1./pwr0, '.-');
end

F=toscs(:,1:NSCS)*todss;
if 1
    %F=F(:,1:20);
    F=nt_normcol(F);
end

nTarget=1;
[~,~,~,cc]=find_source_orient(nt_mmat(g3,F),nTarget);
cc=log10(cc);

h3=subplot(153);
[cc_collapsed,l_collapsed]=collapse_xyz(cc,l,3);
x=l_collapsed(:,1);
y=l_collapsed(:,2);
z=l_collapsed(:,3);
scatter3(x,y,z,10,cc_collapsed,'filled');
colormap (h1, parula);
h=colorbar('southoutside');
set(h,'fontsize',14);
set(get(h,'label'),'string','$log_{10}$(cost)','interpreter','latex', 'fontsize',18);
set(gca,'color',[1 1 1])
set(gca,'xtick',[],'ytick',[],'ztick',[]);
set(gca,'box','off')
set(get(gca,'xaxis'), 'visible','off')
set(get(gca,'yaxis'), 'visible','off')
set(get(gca,'zaxis'), 'visible','off')
colormap(h1,parula);
set(gca,'clim',[-inf 0]);
view(0, 90);
drawnow



% alpha
meg=D.meg;

m=meg;
%g=gain;
g3=gain3;
l=locations;
x=l(:,1);
y=l(:,2);
z=l(:,3);

% SCA
toscs=nt_sca(m);
NSCS=100;

% DSS
f=10;
[B,A]=nt_filter_peak(f/(D.sr/2), 4);
[c0,c1]=nt_bias_filter(meg*toscs(:,1:NSCS),B,A);
if 0
    [B,A]=nt_filter_peak(f/(D.sr/2), 2);
    [~,c0]=nt_bias_filter(meg*toscs(:,1:NSCS),B,A);
end
[todss,pwr0,pwr1]=nt_dss0(c0,c1);

F=toscs(:,1:NSCS)*todss;
if 0
    F=F(:,1:20);
    F=nt_normcol(F);
end
%GSF=g*F;

nTarget=10;
[~,~,~,cc]=find_source_orient(nt_mmat(g3,F),nTarget);
cc=log10(cc);

h4=subplot(154);
[cc_collapsed,l_collapsed]=collapse_xyz(cc,l,3);
x=l_collapsed(:,1);
y=l_collapsed(:,2);
z=l_collapsed(:,3);
scatter3(x,y,z,10,cc_collapsed,'filled');
colormap (parula);
h=colorbar('southoutside');
set(h,'fontsize',14);
set(get(h,'label'),'string','$log_{10}$(cost)','interpreter','latex', 'fontsize',18);
set(gca,'color',[1 1 1])
set(gca,'xtick',[],'ytick',[],'ztick',[]);
set(gca,'box','off')
set(get(gca,'xaxis'), 'visible','off')
set(get(gca,'yaxis'), 'visible','off')
set(get(gca,'zaxis'), 'visible','off')
view(0,-90)
set(gca,'clim',[-inf 0]);


figure(2); clf
set(gcf,'position',[200   597   900   160])

subplot 131
[cc_collapsed,l_collapsed]=collapse_xyz(cc,l,2);
x=l_collapsed(:,1);
y=l_collapsed(:,2);
z=l_collapsed(:,3);
scatter3(x,y,z,10,cc_collapsed,'filled');
colormap (parula);
set(gca,'color',[1 1 1])
set(gca,'xtick',[],'ytick',[],'ztick',[]);
set(gca,'box','off')
set(get(gca,'xaxis'), 'visible','off')
set(get(gca,'yaxis'), 'visible','off')
set(get(gca,'zaxis'), 'visible','off')
view(0,0)
set(gca,'clim',[-inf 0]);
plot_tweak([0 0 0 0])


subplot 132
[cc_collapsed,l_collapsed]=collapse_xyz(cc,l,3);
x=l_collapsed(:,1);
y=l_collapsed(:,2);
z=l_collapsed(:,3);
scatter3(x,y,z,10,cc_collapsed,'filled');
colormap (parula);
set(gca,'color',[1 1 1])
set(gca,'xtick',[],'ytick',[],'ztick',[]);
set(gca,'box','off')
set(get(gca,'xaxis'), 'visible','off')
set(get(gca,'yaxis'), 'visible','off')
set(get(gca,'zaxis'), 'visible','off')
view(0,90)
set(gca,'clim',[-inf 0]);
plot_tweak([-0.01 0 -0.02 0.1])


subplot 133
[cc_collapsed,l_collapsed]=collapse_xyz(cc,l,1);
x=l_collapsed(:,1);
y=l_collapsed(:,2);
z=l_collapsed(:,3);
scatter3(x,y,z,10,cc_collapsed,'filled');
colormap (parula);
h=colorbar('eastoutside');
set(h,'fontsize',14);
set(get(h,'label'),'string','$log_{10}$(cost)','interpreter','latex', 'fontsize',18);
set(h,'ticks',[-1:0.1:0])
set(gca,'color',[1 1 1])
set(gca,'xtick',[],'ytick',[],'ztick',[]);
set(gca,'box','off')
set(get(gca,'xaxis'), 'visible','off')
set(get(gca,'yaxis'), 'visible','off')
set(get(gca,'zaxis'), 'visible','off')
view(-90,0)
set(gca,'clim',[-inf 0]);
plot_tweak([ -.04 0 0.05 0])

