%{
Fig. S3 of WW paper.
%}
if ~check_required; return; end

clear

figure(1); clf
set(gcf,'position',[300   597   1600   350])

clim=[-5 3];

% sensors
nsensors=5; 
sensors=sensor_positions(nsensors);

% sources
sources1=0.5*[0,-1; 0 1; 1,0; -1,0; 0,0];
sources2=0.5*[ 0 -1; 0 ,1; 1,0; -1,0; 0,0; -1 1; 1,-1; -1 -1; 1 1];

% get real EEG data
D=get_dtu_tone;
x=nt_demean(D.data);
x=x(:,1:64,:);

% apply DSS to isolate stimulus-locked component
[todss,pwr0,pwr1]=nt_dss1(x);
fromdss=pinv(todss);
z=nt_mmat(x,todss);
z=nt_normcol(z);

% 5 sources
h4=subplot(1,4,3);
sources=sources1;
GSS=1./sqdist(sources, sensors); % source to sensor gain

% source waveforms
target=z(:,1,:); 
competitors=z(:,2:end,:);
competitors=nt_mmat(competitors,randn(size(z,2)-1,size(sources,1)-1)); % random mix
s=cat(2,target,competitors);   
s=nt_normcol(nt_unfold(s));

% sensor waveforms
X=s*GSS;  

% DSS
[todss]=nt_dss1(nt_fold(X,size(x,1)));

% null filters
F=todss(:,2:end);

NNN=400; 
probes=source_grid(NNN);
GPS=1./sqdist(probes, sensors); % probe to sensor gain

% plot cost function
GPF=GPS*F; % probe to filter gain
GPF=reshape(GPF, NNN,NNN,size(GPF,2));
mask=zerox(GPF);
GPF=GPF.*mask;
G=sum(GPF.^2,3);
G=log10(G);
G=zero_outside(G,max(G(:)));
imagesc([-1, 1],[-1,1], G');
hold on
plotsensors(sensors);

colormap(h4, 'gray');
plot_tweak([0 0.1 0 -.1], h4)
drawcross(sources,'g',0.1, 0, 'linewidth', 1);
drawcross(sources(1,:),'r',0.2, 1, 'linewidth', 2);
set(gca,'box','off')
set(get(gca,'xaxis'), 'visible','off')
set(get(gca,'yaxis'), 'visible','off')
set(gca,'clim', clim);

% 9  sources
h4=subplot(1,4,4);

sources=sources2;
GSS=1./sqdist(sources, sensors); % source to sensor gain

% source waveforms
target=z(:,1,:); 
competitors=z(:,2:end,:);
competitors=nt_mmat(competitors,randn(size(z,2)-1,size(sources,1)-1)); % random mix
s=cat(2,target,competitors);   
s=nt_normcol(nt_unfold(s));

% sensor waveforms
X=s*GSS;  

% DSS
[todss]=nt_dss1(nt_fold(X,size(x,1)));

% null filters
F=todss(:,2:end);

NNN=400; 
probes=source_grid(NNN);
GPS=1./sqdist(probes, sensors); % probe to sensor gain

% plot cost function
GPF=GPS*F; % probe to filter gain
GPF=reshape(GPF, NNN,NNN,size(GPF,2));
mask=zerox(GPF);
GPF=GPF.*mask;
G=sum(GPF.^2,3);
G=log10(G);
G=zero_outside(G,max(G(:)));
imagesc([-1, 1],[-1,1], G');
hold on
plotsensors(sensors);

colormap(h4, 'gray');
plot_tweak([0 0.1 0 -.1], h4)
drawcross(sources,'g',0.1, 0, 'linewidth', 1);
drawcross(sources(1,:),'r',0.2, 1, 'linewidth', 2);
set(gca,'box','off')
set(get(gca,'xaxis'), 'visible','off')
set(get(gca,'yaxis'), 'visible','off')
set(gca,'clim', clim);


% ground truth
h1=subplot(1,4,1);
A=ones(NNN,NNN)*10;
A=zero_outside(A);
image([-1,1],[-1,1],256-A);
hold on
plotsensors(sensors);

set(gca,'clim',clim);
colormap(h1,'gray');
sources=sources1;
drawcross(sources,'g', 0.1, [], 'linewidth', 2)
drawcross(sources(1,:),'b',0.05, 0, 'linewidth', 2);
set(gca,'box','off')
set(get(gca,'xaxis'), 'visible','off')
set(get(gca,'yaxis'), 'visible','off')

plot_tweak([0 0.1 0 -.1], h1)


% source waveform
h2=subplot(2,4,2); nt_imagescc(squeeze(z(:,1,:))');
colormap(h2, 'jet');
set(gca, 'xtick', [10 61 112], 'xticklabel', {'0', '0.1', '0.2'});
set(gca, 'fontsize',14);
xlabel('time (s)'); ylabel('trial');
title('target source');
plot_tweak([0 0.1 0 -.1], h2)

% competitor waveform
h3=subplot(2,4,6); nt_imagescc(squeeze(z(:,6,:))');
colormap(h3, 'jet');
set(gca, 'xtick', [10 61 112], 'xticklabel', {'0', '0.1', '0.2'});
set(gca, 'fontsize',14);
xlabel('time (s)'); ylabel('trial');
title('another source (one of 4)');
plot_tweak([0 0.1 0 -.1], h3)

