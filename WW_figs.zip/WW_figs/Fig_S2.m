%{
Fig. S2 of WW paper.
%}
clear

rng(0); 
rand(125,1); % adjust for visual effect

figure(1); clf
set(gcf,'position',[300   597   900   500])

% sensor positions
nsensors=6;
sensors=sensor_positions(nsensors);

% probe grid (source model)
NNN=300; 
probes=source_grid(NNN);

% source positions
sources=[0.5,-.4];
sensors=sensor_positions(nsensors);

% source to sensor and probe to sensor gains
GSS=1./sqdist(sources, sensors); 
GPS=1./sqdist(probes, sensors); 

% source and sensor waveforms
s=randn(1000,size(sources,1)); % 
X=s*GSS; % observations

% PCA
topcs=nt_pca0(X); %

% plot gain map
F=topcs(:,5); % spatial filter
h1=subplot(2,3,1);
G=reshape(GPS*F,NNN,NNN); % gain 
[G,ticks,ticklabels]=symlog(G*1,[],0.1);
mask=zerox(G,0.1);
G=G.*mask;
G=zero_outside(G,nan);
hh=surfc(G); shading interp

set(hh(2), 'levellist',-10:0.2:10)
jet1=jet; jet1(1,:)=1; jet1(129,:)=0;
colormap(h1,jet1);
set(gca,'xtick',[],'ytick',[])
set(gca, 'ztick',ticks,'zticklabel',ticklabels);
set(gca,'zlim',[-2.5 2.5], 'clim',[-3 3]);
zlabel('gain', 'interpreter', 'latex', 'fontsize',18);
set(gca, 'cameraposition', [4000 -1000 20])


% plot squared gain map
h3=subplot(2,3,2);
G=reshape(GPS*F,NNN,NNN); % gain 
G=G.*mask;
G=log10(G.^2);
G=max(G,-3);
G=zero_outside(G,nan);
hh=surfc(G); shading interp

set(hh(2), 'levellist',-10:0.5:10)
jet1=jet; jet1(1,:)=1; jet1(129,:)=0;
colormap(h3,gray);
set(gca,'xtick',[],'ytick',[])
set(gca, 'ztick',[-2 0 2],'zticklabel',[.01  1 100]);
set(gca,'zlim',[-4 3], 'clim',[-3 3]);
zlabel('gain$^2$', 'interpreter', 'latex', 'fontsize',18);
set(gca, 'cameraposition', [4000 -1000 20])


% plot zero sets
h7=subplot(2,3,3);
F=topcs(:,2:end); % spatial filter
GPF=reshape(GPS*F,NNN,NNN,nsensors-1); % gain 
mask=zerox(GPF);
mask=1-mask;
mask=cat(3,mask(:,:,1), mask(:,:,2)*2, mask(:,:,3)*3, mask(:,:,4)*4);
mask=zero_outside(mask);
mask=mask+2;
mask=max(mask,[],3);
image([-1 1], [-1, 1],mask'); 
hold on
plotsensors(sensors);

cmap=gray;
cmap(1,:)=1;
cmap(2,:)=0.97;
cmap(3,:)=0.6; %[0.1 0.1 1];
cmap(4,:)=0.7; %[0 1 1];
cmap(5,:)=0.8; %[0.1 1 0.1];
cmap(6,:)=[1 0.1 0.1];
set(gca,'colormap', cmap)
drawcross(sources,'g',0.3, 1, 'linewidth', 2);
set(gca,'box','off')
set(get(gca,'xaxis'), 'visible','off')
set(get(gca,'yaxis'), 'visible','off')

% sum of squared gain maps
h9=subplot(2,2,3);
C=log10(sum(GPF.^2,3));
C=zero_outside(C,nan);
hh=surfc(C); shading interp;

set(hh(2), 'levellist',-10:0.5:10)
colormap(h9,gray);
zlim([-4 6])
set(gca,'fontsize',14);
set(gca,'box','off')
set(gca,'clim', [-5 7])
zlabel('$o(x,y)$', 'interpreter', 'latex', 'fontsize',18)
set(gca, 'xtick',[],'ytick', [], 'ztick',[-4 -2 0 2 4], 'zticklabel',[.0001 .01 1 100 10000])
set(gca, 'cameraposition', [4000 -1000 20])

% same, with bias
bias=mean(abs(GPS),2);
bias=reshape(bias,NNN,NNN);
GPF=bsxfun(@times, GPF, 1./bias);

h9=subplot(2,2,4);
C=log10(sum(GPF.^2,3));
C=zero_outside(C,nan);
hh=surfc(C); shading interp;

set(hh(2), 'levellist',-10:0.5:10)
colormap(h9,gray);
zlim([-4 6])
set(gca,'fontsize',14);
set(gca,'box','off')
set(gca,'clim', [-5 7])
zlabel('$\tilde{o}(x,y)$', 'interpreter', 'latex', 'fontsize',18)
set(gca, 'xtick',[],'ytick', [], 'ztick',[-4 -2 0 2 4], 'zticklabel',[.0001 .01 1 100 10000])
set(gca, 'cameraposition', [4000 -1000 20])

