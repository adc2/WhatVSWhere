function ok=check_required
%
% check whether required toolboxes and data are available
ok=1;

disp('checking for toolboxes & data...');
% check for required toolboxes
try, nt_greetings; 
catch, disp('Download NoiseNools from http://audition.ens.fr/adc/NoiseTools/, put in path'); ok=0; end

try, ft_version; 
catch, disp('Download FieldTrip from http://www.fieldtriptoolbox.org, put in path'); ok=0; end

try, SpiralSampleSphere; 
catch, disp('Download S^2 sampling toolbox from https://www.mathworks.com/matlabcentral/fileexchange/37004-suite-of-functions-to-perform-uniform-sampling-of-a-sphere'); return; end

try, bst_plugin('Install', 'spm12')
catch, disp('call to bst_plugin failed'); 
    disp('Brainstorm needs to be installed (https://neuroimage.usc.edu/brainstorm/) and running'); ok=0; end

if ~2==exist('file_array')
    disp('get bst to install spm12 plugin (to get file_array)');
    ok=0
end

if ~isfile('../from_bst/head_model_15002.mat')
    disp('../from_bst/head_model_15002.mat not found')
    disp('Use Brainstorm to create head model for tutorial MEG dataset, and save it in a file with this name.')
    disp('Cortical surface, constrained, parameters as in tutorial.')
    ok=0;
end

if ~isfile('../from_bst/head_model_MEG_sample_introduction_run1_volume_2mm.mat')
    disp('../from_bst/head_model_volume_2mm.mat not found')
    disp('Use Brainstorm to create head model for tutorial MEG dataset, and save it in a file with this name.')
    disp('Volume, 2mm grid, other parameters as in tutorial.')
    ok=0;
end

if ~isdir('../brainstorm/brainstorm data/sample_introduction/data/S01_AEF_20131218_02_600Hz.ds')
    disp('../brainstorm/brainstorm data/sample_introduction/data/S01_AEF_20131218_02_600Hz.ds not found')
    disp('Download from Brainstorm site, adjust path.')
    ok=0;
end

if ~isfile('../BST epilepsy EEG/SPIKE_trial001.dat')
    disp('../BST epilepsy EEG/SPIKE_trial001.dat not found');
    disp('Download sample_epilepsy.zip from https://neuroimage.usc.edu/bst/download.php, adjust path');
    return;
end

if ~isfile('../from_bst/head_model_epilepsy_EEG_volume_2mm.mat')
    disp('../from_bst/head_model_epilepsy_EEG_volume_2mm.mat not found');
    disp('Use Brainstorm to create head model for tutorial EEG epilepsy dataset, and save it in a file with this name.')
    disp('Volume, 2mm grid, other parameters as in tutorial.')
    return;
end

if ~isdir('/Users/adc/data/MEG/DTU/ds-eeg-snhl/')
    disp('/Users/adc/data/MEG/DTU/ds-eeg-snhl/ not found');
    disp('Download from From: https://zenodo.org/record/3618205#.YX760S-l3r0, adjust path'); 
    return;
end

    
    
    disp('...done');
ok=1;

