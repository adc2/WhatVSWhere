%{
Fig. 2 of WW paper.
%}
if ~check_required; return; end

clear

rng('default');
rand(2,1); % --> better picture

figure(1); clf
set(gcf,'position',[300   597   600 650])

% colors to use in plots
if 0
    % lighter
    blue = [114 147 203]./255;
    red = [211 94 96]./255;
    black = [128 133 133]./255;
    green = [132 186 91]./255;
    brown = [171 104 87]./255;
    purple = [144 103 167]./255;
else 
    % darker
    blue = [57 106 177]./255;
    red = [204 37 41]./255;
    black = [83 81 84]./255;
    green = [62 150 81]./255;
    brown = [146 36 40]./255;
    purple = [107 76 154]./255;
end
cl=[blue;red;black;green;brown;purple];


% sensor positions
nsensors=5; 
sensors=sensor_positions(nsensors);

% probe grid (source model)
NNN=500; 
probes=source_grid(NNN);

% source position
sources=[0.5,-0.4];

% source to sensor and probe to sensor gains
GSS=1./sqdist(sources, sensors); 
GPS=1./sqdist(probes, sensors); 

% log amplitude of field from source
A=1./sqdist(probes,sources); % field around source
A=reshape(A,NNN,NNN);

% plot toy world with source and amplitude map
h1=subplot(2,2,1);
A=log10(A*10);
A=zero_outside(A,0); % clip to circle
imagesc([-1 1], [-1,1], A')
hold on
plotsensors(sensors);

h2=colorbar('southoutside');
set(h2, 'ticks', [0 1 2 3 4] ,'ticklabels',{'.01', '.1', '1','10','100'}, ...
    'TickLabelInterpreter', 'tex', 'fontsize',14, 'limits',[0 4])
set(get(h2,'label'), 'string', 'amplitude (a.u.)');
drawcross(sources,'g', 0.2);

set(gca,'box','off')
set(get(gca,'xaxis'), 'visible','off')
set(get(gca,'yaxis'), 'visible','off')
jet1=jet; jet1(129,:)=1;
colormap(h1,jet1)
set(gca,'clim',[-4 4]);

plot_tweak([0 -.03 0 .03], h1)

% plot gain pattern of 2-coeff spatial filter
h5=subplot(2,2,2);

F=[0,0,0.23, 0,-1]'; % hand-crafted spatial filter
G=GPS*F; % probe to null filter gain
G=reshape(G,NNN,NNN);
zerosetmask=zerox(G);
[G,ticks,ticklabels]=symlog(G*10,[],0.1);
G=G.*zerosetmask;
G=max(G,-3.9); % kludge to avoid glitch mear sensor
G=zero_outside(G,nan); % clip to circle
imagesc([-1 1], [-1, 1],G');
hold on; 
plotsensors(sensors);

h6=colorbar('southoutside');
set(h6,'ticks', [-2 -1 0 1 2], 'ticklabels',{'-100','-10', '0','10', '100'},'fontsize',14, 'limits',[-2.5 2.5], 'fontsize',14)
set(get(h6,'label'), 'string', 'gain');

jet1=jet; jet1(1,:)=1; jet1(129,:)=0;
colormap(h5,jet1);
drawcross(sources,green, 0.2, []);
set(gca,'box','off')
set(get(gca,'xaxis'), 'visible','off')
set(get(gca,'yaxis'), 'visible','off')
set(gca,'clim',[-4 4]);

plot_tweak([0 -.03 0 .03], h5)


% plot multiple zero sets

h7=subplot(2,2,3);

nsensors=5; % 5 sensors
S=sensor_positions(nsensors);
s=randn(1000,size(sources,1)); % sources time series
M=1./sqdist(sources,S);
X=s*M; % observations
topcs=nt_pca0(X); %? PCA
F=topcs(:,2:end); % spatial filter

NNN=200; % defines density of probe grid
probes=source_grid(NNN);
G=source2sensor(probes,S); 
G=reshape(G,NNN*NNN,nsensors);

GPF=reshape(G*F,NNN,NNN,4); % gain 
F0=topcs; % spatial filter
GPF0=reshape(G*F0,NNN,NNN,5); % gain 
widen=1;
zerosetmask=zerox(GPF,widen);
zerosetmask=1-zerosetmask;
zerosetmask=cat(3,zerosetmask(:,:,1), zerosetmask(:,:,2)*2, zerosetmask(:,:,3)*3, zerosetmask(:,:,4)*4);
zerosetmask=zerosetmask+1;
zerosetmask=zero_outside(zerosetmask);
zerosetmask=zerosetmask+1;
zerosetmask=max(zerosetmask,[],3);

image([-1 1], [-1, 1],zerosetmask'); 

jet1=gray;
jet1(1,:)=1;
jet1(2,:)=0;%0.90;
jet1(3,:)=blue; %[0.1 0.1 1];
jet1(4,:)=green; %[0 1 1];
jet1(5,:)=purple; %[0.1 1 0.1];
jet1(6,:)=[1 0.1 0.1];
%cmap(3:5,:)=0.5;

set(h7,'colormap', jet1)
drawcross(sources,'g',0.3, 1);
set(gca,'box','off')
set(get(gca,'xaxis'), 'visible','off')
set(get(gca,'yaxis'), 'visible','off')

hold on
N=100;
x=sin(2*pi*(1:N+1)/N);
y=cos(2*pi*(1:N+1)/N);
plot(x,y, 'k', 'linewidth', 2);
a=1.05;
plot(sensors(:,1)*a,sensors(:,2)*a, '.', 'color', [0,0.2,1],'markersize',40);
xlim([-a,a]); ylim([-a,a]);


plot_tweak([0 0.06 0 -0.06], h7)



h9=subplot(2,2,4);
G=log10(sum(GPF.^2,3)./sum(GPF0.^2,3));
G=zero_outside(G,nan);
hh=surfc(G); shading interp;
set(hh(2), 'levellist',fliplr(-[.05:0.2:4]))
colormap(h9,gray);
zlim([-4 0])

set(gca,'fontsize',16);
set(gca,'box','off')
set(gca,'clim', [-3 0.5])
zlabel('cost($x,y$)', 'interpreter', 'latex', 'fontsize',20)
%xlabel('$x$', 'interpreter', 'latex'); ylabel('$y$', 'interpreter', 'latex')
set(gca, 'xtick',[],'ytick', [], 'ztick',[-4 -3 -2 -1 0], 'zticklabel', [.0001 .001 .01 0.1 1])

plot_tweak([0 0.05 0 -.05], h9)

plot_tweak([0.07 0 0 0], h9)
set(gca, 'cameraposition', [4000 -1000 20])



