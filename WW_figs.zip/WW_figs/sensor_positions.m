function S=sensor_positions(nsensors)
% create sensor positions

nsensors=nsensors+1;
S=[sin(2*pi*(1:nsensors)/nsensors)', cos(2*pi*(1:nsensors)/nsensors)'];
%S(S(:,2)>0.9,:)=[]; % delete lowest positions
[~,idx]=max(S(:,2));
S(idx,:)=[]; % delete lowest positions
