% 
% W&W
% 
% analyze Brainstorm tutorial data
clear
%rng(0)


% head model
load ../from_bst/head_model_15002 % gain matrix and grid coordinates
head_model=head_model_15002;
%load ./brainstorm/head_model % gain matrix and grid coordinates (45006 locations)
[gain3,gain,locations,orientations]=headmodelparse(head_model); 

% all locations?
idxLocationsL=find(locations(:,2)>=0);
idxLocationsR=find(locations(:,2)<=0);

% MEG data
if 0
    D=read_brainstorm_meg;
    save ../tmp/tmp_Fig_S10 D;
else
    load ../tmp/tmp_Fig_S10;
end
meg=cat(3,D.s,D.d); 
meg=D.s; 

% all sensors?
idxGrad=1:274; % guess based on lables
idxSensorsL=find(D.h.grad.chanpos(idxGrad,2)>=0);
idxSensorsR=find(D.h.grad.chanpos(idxGrad,2)<=0);

if 0
    % filter?
    meg=nt_demean2(meg,1:120);
    [B,A]=butter(2,1/(D.sr/2),'high');
    meg=filter(B,A,meg);
    [B,A]=butter(2,20/(D.sr/2),'low');
    %s=filter(B,A,s);
end

% suppress outlier trials
idx=nt_find_outlier_trials(meg,2.5);
meg=meg(:,:,idx);


figure(1); clf
set(gcf,'position',[200   597   1200   200])
background=[1 1 1]*1;


% auditory, left hemisphere
m=meg(:,idxSensorsL,:);
g=gain(idxLocationsL,idxSensorsL);
l=locations(idxLocationsL,:);
x=l(:,1);
y=l(:,2);
z=l(:,3);

% SCA
toscs=nt_sca(m);
NSCS=100;

% DSS
FOCUS=1:200; % 330 ms
[todss,pwr0,pwr1]=nt_dss1(nt_mmat(m(FOCUS,:,:),toscs(:,1:NSCS)));
if 0
    figure(1); clf;
    plot(pwr1./pwr0, '.-');
end

F=toscs(:,1:NSCS)*todss;
if 1
    %F=F(:,1:30);
    F=nt_normcol(F);
end
GSF=g*F;

nTarget=1;
exponent=2;
[~,~,cc]=find_source(g*F,nTarget,exponent);
cc=log10(cc);


[~,idx]=sort(cc);
NLOC=4000;
[loc, val,c, C]=find_source_pair(g(idx(1:NLOC),:)*F, nTarget,exponent);
c=c/max(c(:));
c=log10(c);

h1=subplot(151);
scatter3(x,y,z, 10, ones(size(g,1),1)*max(c(:)*257/256), 'filled'); 
hold on;
scatter3(x(idx(1:NLOC)),y(idx(1:NLOC)),z(idx(1:NLOC)),10,c,'filled'); 
parula1=parula; parula1(end,:)=[1 1 1]*0.9;
colormap (h1, parula1);
view(180, 0);
h=colorbar('southoutside');
set(h,'fontsize',14);
set(get(h,'label'),'string','$log_{10}$(cost)','interpreter','latex', 'fontsize',18);
view(180, 0);
set(gca,'color',[1 1 1])
set(gca,'xtick',[],'ytick',[],'ztick',[]);
set(gca,'box','off')
set(get(gca,'xaxis'), 'visible','off')
set(get(gca,'yaxis'), 'visible','off')
set(get(gca,'zaxis'), 'visible','off')
%set(gca,'clim',[-0.5 0]);


% auditory, right hemisphere
m=meg(:,idxSensorsR,:);
g=gain(idxLocationsR,idxSensorsR);
l=locations(idxLocationsR,:);
x=l(:,1);
y=l(:,2);
z=l(:,3);

% SCA
toscs=nt_sca(m);
NSCS=100;

% DSS
FOCUS=1:200; % 330 ms
[todss,pwr0,pwr1]=nt_dss1(nt_mmat(m(FOCUS,:,:),toscs(:,1:NSCS)));
if 0
    figure(1); clf;
    plot(pwr1./pwr0, '.-');
end

F=toscs(:,1:NSCS)*todss;
if 1
    %F=F(:,1:20);
    F=nt_normcol(F);
end
GSF=g*F;

nTarget=1;
exponent=2;
[~,~,cc]=find_source(g*F,nTarget,exponent);
cc=log10(cc);

[~,idx]=sort(cc);
NLOC=4000;
[loc, val,c, C]=find_source_pair(g(idx(1:NLOC),:)*F, nTarget,exponent);
c=c/max(c(:));
c=log10(c);

h2=subplot(152)
scatter3(x,y,z, 10, ones(size(g,1),1)*max(c(:)*257/256), 'filled'); 
hold on;
scatter3(x(idx(1:NLOC)),y(idx(1:NLOC)),z(idx(1:NLOC)),10,c,'filled'); 
colormap (h2, parula1);
view(0, 0);
h=colorbar('southoutside');
set(h,'fontsize',14);
set(get(h,'label'),'string','$log_{10}$(cost)','interpreter','latex', 'fontsize',18);
view(0, 0);
set(gca,'color',[1 1 1])
set(gca,'xtick',[],'ytick',[],'ztick',[]);
set(gca,'box','off')
set(get(gca,'xaxis'), 'visible','off')
set(get(gca,'yaxis'), 'visible','off')
set(get(gca,'zaxis'), 'visible','off')
%set(gca,'clim',[-0.5 0]);


% button press
meg=D.b;

if 0
    % filter?
    meg=nt_demean2(meg,1:120);
    [B,A]=butter(2,1/(D.sr/2),'high');
    meg=filter(B,A,meg);
    [B,A]=butter(2,20/(D.sr/2),'low');
    %s=filter(B,A,s);
end

% suppress outlier trials
% idx=nt_find_outlier_trials(meg,2.5);
% meg=meg(:,:,idx);

m=meg;
g=gain;
l=locations;
x=l(:,1);
y=l(:,2);
z=l(:,3);

% SCA
toscs=nt_sca(m);
NSCS=100;

% DSS
FOCUS=301:600; % % 500ms before press
[todss,pwr0,pwr1]=nt_dss1(nt_mmat(m(FOCUS,:,:),toscs(:,1:NSCS)));
if 0
    figure(1); clf;
    plot(pwr1./pwr0, '.-');
end

F=toscs(:,1:NSCS)*todss;
if 1
    %F=F(:,1:20);
    F=nt_normcol(F);
end
GSF=g*F;

nTarget=1;
exponent=2;
[~,~,cc]=find_source(g*F,nTarget,exponent);
cc=log10(cc);

[~,idx]=sort(cc);
NLOC=4000;
[loc, val,c, C]=find_source_pair(g(idx(1:NLOC),:)*F, nTarget,exponent);
c=c/max(c(:));
c=log10(c);

h3=subplot(153)
scatter3(x,y,z, 10, ones(size(g,1),1)*max(c(:)*257/256), 'filled'); 
hold on;
scatter3(x(idx(1:NLOC)),y(idx(1:NLOC)),z(idx(1:NLOC)),10,c,'filled');
colormap (h3, parula1);
view(180, 0);
h=colorbar('southoutside');
set(h,'fontsize',14);
set(get(h,'label'),'string','$log_{10}$(cost)','interpreter','latex', 'fontsize',18);
view(0, 90);
set(gca,'color',[1 1 1])
set(gca,'xtick',[],'ytick',[],'ztick',[]);
set(gca,'box','off')
set(get(gca,'xaxis'), 'visible','off')
set(get(gca,'yaxis'), 'visible','off')
set(get(gca,'zaxis'), 'visible','off')
%set(gca,'clim',[-0.3 0]);


% alpha
meg=D.meg;

m=meg;
g=gain;
l=locations;
x=l(:,1);
y=l(:,2);
z=l(:,3);

% SCA
toscs=nt_sca(m);
NSCS=100;

% DSS
f=10;
[B,A]=nt_filter_peak(f/(D.sr/2), 4);
[c0,c1]=nt_bias_filter(meg*toscs(:,1:NSCS),B,A);
if 0
    [B,A]=nt_filter_peak(f/(D.sr/2), 2);
    [~,c0]=nt_bias_filter(meg*toscs(:,1:NSCS),B,A);
end
[todss,pwr0,pwr1]=nt_dss0(c0,c1);

F=toscs(:,1:NSCS)*todss;
if 0
    F=F(:,1:20);
    F=nt_normcol(F);
end
GSF=g*F;

nTarget=10;
exponent=2;
[~,~,cc]=find_source(g*F,nTarget,exponent);
cc=log10(cc);

[~,idx]=sort(cc);
NLOC=4000;
[loc, val,c, C]=find_source_pair(g(idx(1:NLOC),:)*F, nTarget,exponent);
c=c/max(c(:));
c=log10(c);

h4=subplot(154);
scatter3(x,y,z, 10, ones(size(g,1),1)*max(c(:)*257/256), 'filled'); 
hold on;
scatter3(x(idx(1:NLOC)),y(idx(1:NLOC)),z(idx(1:NLOC)),10,c,'filled');
colormap (h4, parula1);
view(180, 0);
h=colorbar('southoutside');
set(h,'fontsize',14);
set(get(h,'label'),'string','$log_{10}$(cost)','interpreter','latex', 'fontsize',18);
view(0, 90);
set(gca,'color',[1 1 1])
set(gca,'xtick',[],'ytick',[],'ztick',[]);
set(gca,'box','off')
set(get(gca,'xaxis'), 'visible','off')
set(get(gca,'yaxis'), 'visible','off')
set(get(gca,'zaxis'), 'visible','off')
view(0,-90)
set(gca,'clim',[-1.2 0]);





return

[~,idx]=sort(cc);
NLOC=2000;
[loc, val,c, C]=find_source_pair(GSF(idx(1:NLOC),:), nTarget,exponent);


figure(3); clf;
scatter3(x(idx(1:NLOC)),y(idx(1:NLOC)),z(idx(1:NLOC)),60,c,'filled'); colorbar
colormap parula
view(1800, 0);


