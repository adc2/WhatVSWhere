%{
Fig. S7 of WW paper.
%}
if ~check_required; return; end
clear
%rng(0)

figure(1); clf
set(gcf,'position',[200   597   1200   200])
background=[1 1 1]*1;
load ../from_bst/head_model_15002 % gain matrix and grid coordinates
head_model=head_model_15002;
%load ./brainstorm/head_model % gain matrix and grid coordinates (45006 locations)
[gain3,gain,loc,orient]=headmodelparse(head_model); 
x=loc(:,1);
y=loc(:,2);
z=loc(:,3);

[~,idx]=sort(loc(:,2)); % leftmost locations (for visual clarity)

% source is single dipole
idxSource=idx(1);

% ground truth
h1=subplot(151);
ground_truth=ones(size(gain,1),1);
ground_truth(idxSource)=0;
scatter3(x,y,z, 60, ground_truth); view(0, 0);
set(gca,'color',background)
set(gca,'xtick',[],'ytick',[],'ztick',[]);
set(gca,'box','off')
set(get(gca,'xaxis'), 'visible','off')
set(get(gca,'yaxis'), 'visible','off')
set(get(gca,'zaxis'), 'visible','off')
plot_tweak([0, 0.3, 0,-0.3]);
colormap(h1,'gray');
set(gca,'clim',[0 1.1]);

% null filters
s=randn(10000,1); %source waveform
s=repmat(s,1,numel(idxSource));
X=s*gain(idxSource,:); % sensor waveforms
topcs=nt_pca0(X);

F=topcs;
exponent=2;
nTarget=1;
%g=gain+0.000000001*randn(size(gain))*sqrt(mean(gain(:).^2));
[~,~,C]=find_source(gain*F,nTarget,exponent);

h2=subplot(152);
C=C/max(C(:));
C=log10(C);
scatter3(x,y,z, 60, C, 'filled'); 
h=colorbar('southoutside');
set(h,'fontsize',14);
set(get(h,'label'),'string','$log_{10}$(cost)','interpreter','latex', 'fontsize',18);
view(0, 0);
set(gca,'color',background)
set(gca,'xtick',[],'ytick',[],'ztick',[]);
set(gca,'box','off')
set(get(gca,'xaxis'), 'visible','off')
set(get(gca,'yaxis'), 'visible','off')
set(get(gca,'zaxis'), 'visible','off')
colormap (h2,parula)
set(gca,'clim',[-20 0]);

% with noise

% null filters
s=randn(10000,1); %source waveform
s=repmat(s,1,numel(idxSource));
X=s*gain(idxSource,:); % sensor waveforms
noise=randn(size(X))*sqrt(sum(X(:).^2)/numel(X));
X=X+10*noise;
[topcs,pwr]=nt_pca0(X);

F=topcs;
exponent=2;
nTarget=1;
[~,~,C]=find_source(gain*F,nTarget,exponent);

h3=subplot(153);
C=C/max(C(:));
C=log10(C);
scatter3(x,y,z, 60, C, 'filled'); 
h=colorbar('southoutside');
set(h,'fontsize',14);
set(get(h,'label'),'string','$log_{10}$(cost)','interpreter','latex', 'fontsize',18);
view(0, 0);
set(gca,'color',background)
set(gca,'xtick',[],'ytick',[],'ztick',[]);
set(gca,'box','off')
set(get(gca,'xaxis'), 'visible','off')
set(get(gca,'yaxis'), 'visible','off')
set(get(gca,'zaxis'), 'visible','off')
colormap (h3,parula)
set(gca,'clim',[-4 0]);


if 0
    D=read_brainstorm_meg;
    s=cat(3,D.s,D.d); 
    toscs=nt_sca(s);
    NSCS=70;
    [todss,pwr0,pwr1]=nt_dss1(nt_mmat(s,toscs(:,1:NSCS)));
    if 1
        figure(1); clf;
        plot(pwr1./pwr0, '.-');
    end
    NREMOVE=4;
    fromscs=pinv(toscs);
    fromdss=pinv(todss);

    totarg=toscs(:,1:NSCS)*todss(:,1)*fromdss(1,:)*fromscs(1:NSCS,:);
    toback=toscs(:,1:NSCS)*todss(:,NREMOVE+1:end)*fromdss(NREMOVE+1:end,:)*fromscs(1:NSCS,:);
    
    target=nt_mmat(s,totarg);
    
    if 0
        background=nt_mmat(s, toback);  % --> linearly separable
    else
        background=nt_phase_scramble(s); % --> inseparable
    end
    
    disp('target to background power:');
    ttb=nt_wpwr(target)/nt_wpwr(background);
    disp(ttb);
    save ../tmp/tmp_Fig_S7 target background ttb toscs todss
else
    load ../tmp/tmp_Fig_S7
end

% synthetic data
target=nt_pca(target);
target=repmat(target(:,1),[1,numel(idxSource),1]);
T=nt_mmat(target,gain(idxSource,:)); % sensor waveforms for target
B=background;
T=T*sqrt(ttb)*sqrt(mean(B(:).^2))/sqrt(mean(T(:).^2)); % scale target for same SNR as in real data
X=1*B+T;

% null filters
[todss,pwr0,pwr1]=nt_dss1(X);
if 0
    figure(10); clf; plot(pwr1./pwr0, '.-');
    figure(1)
end
F=todss;

exponent=2;
nTarget=1;
[~,~,C]=find_source(gain*F,nTarget,exponent);

% C=cost_function3(gain,F,1);
% C=C/max(C(:));
% 
h4=subplot(154);
C=log10(C);
scatter3(x,y,z, 60, C, 'filled'); 
h=colorbar('southoutside');
set(h,'fontsize',14);
set(get(h,'label'),'string','$log_{10}$(cost)','interpreter','latex', 'fontsize',18);
view(0, 0);
set(gca,'xtick',[],'ytick',[],'ztick',[]);
set(gca,'box','off')
set(get(gca,'xaxis'), 'visible','off')

set(get(gca,'yaxis'), 'visible','off')
set(get(gca,'zaxis'), 'visible','off')
colormap (h4,parula)
set(gca,'clim',[-4 0]);

% difference between each gain vector and the closest of the other gain vectors
d=1-abs(nt_cov(nt_normcol(gain')))/size(gain,2);
d=sqrt(d);
d=d+eye(size(d,1))*max(d(:));
dmin=min(d);

return

subplot 155

% plot cumulative histogram
[a,b]=hist(dmin(:),30);
b(1)=min(d(:));
semilogx(b, cumsum(a)/sum(a)*100, '.-k');
set(gca,'xtick',[0.01 0.1 1]);
xlim([0.01 1]);
set(gca,'fontsize',14)
set(gca,'ytick',[0 50 100]);
xlabel('distance'); ylabel('%');
set(gca,'xgrid','on','ygrid','on');
plot_tweak([0.02, 0.2, 0,-0.2]);

