% 
% W&W
% 
% analyze Brainstorm tutorial data
clear
addpath sphere_sampling
%rng(0)

figure(1); clf
set(gcf,'position',[200   597   1200   200])

load ./head_model_15002 % gain matrix and grid coordinates
head_model=head_model_15002;
%load ./brainstorm/head_model % gain matrix and grid coordinates (45006 locations)
[gain3,gain,loc,orient]=headmodelparse(head_model); 
x=loc(:,1);
y=loc(:,2);
z=loc(:,3);

[~,idx]=sort(head_model.GridLoc(:,2)); % leftmost locations

idxSource=idx(1);

s=randn(10000,1); %source waveform
s=repmat(s,1,numel(idxSource));

SNRs=10.^[-1:20];
depth=zeros(size(SNRs));
depth2=zeros(size(gain,1),numel(SNRs));
for iSNR=1:numel(SNRs)  
    g=gain+randn(size(gain))*sqrt(mean(gain(:).^2))/SNRs(iSNR);
    % null filters
    X=s*g(idxSource,:); % sensor waveforms
    topcs=nt_pca0(X);

    F=topcs;
    exponent=2;
    nTarget=1;
    [~,~,C]=find_source(gain*F,nTarget,exponent);
    depth(iSNR)=min(C(:));
    depth2(:,iSNR)=sort(C);
end

h1=subplot(141);
loglog(SNRs,depth, '.-k');
set(gca,'xtick',[1 10^10 10^20]);
set(gca,'fontsize',14)
set(gca,'ytick',[10^-30 10^-20 10^-10 1]);
xlabel('SNR(gain)'); ylabel('cost at min');
set(gca,'xgrid','on','ygrid','on');
plot_tweak([0, 0.2, -0.04,-0.2],h1);


% source is multiple dipoles
idxSource=idx(1:10);

% ground truth
h2=subplot(152);
ground_truth=ones(size(gain,1),1);
ground_truth(idxSource)=0;
scatter3(x,y,z, 20, ground_truth, 'filled'); view(0, 0);
set(gca,'color',[1 1 1])
set(gca,'xtick',[],'ytick',[],'ztick',[]);
set(gca,'box','off')
set(get(gca,'xaxis'), 'visible','off')
set(get(gca,'yaxis'), 'visible','off')
set(get(gca,'zaxis'), 'visible','off')
colormap(h2,'gray');
set(gca,'clim',[0 1.1]);
drawnow

% null filters
s=randn(10000,numel(idxSource)); %source waveform
s=nt_normcol(nt_pca(s)); % perfectly decorrelated
%s=0.001*s+repmat(s(:,1),1,numel(idxSource)); % introduce correlation
X=s*gain(idxSource,:); % sensor waveforms
topcs=nt_pca0(X);

F=topcs;
exponent=2;
nTarget=numel(idxSource);
[~,~,C]=find_source(gain*F,nTarget,exponent);

h3=subplot(153);
C=C/max(C(:));
C=log10(C);
scatter3(x,y,z, 30, C, 'filled'); 
h=colorbar('southoutside');
set(h,'fontsize',14);
set(get(h,'label'),'string','$log_{10}$(cost)','interpreter','latex', 'fontsize',18);
view(0, 0);
set(gca,'color',[1 1 1])
set(gca,'xtick',[],'ytick',[],'ztick',[]);
set(gca,'box','off')
set(get(gca,'xaxis'), 'visible','off')
set(get(gca,'yaxis'), 'visible','off')
set(get(gca,'zaxis'), 'visible','off')
colormap (h3,parula)
%set(gca,'clim',[-2 0]);

plot_tweak([0, 0.3, 0,-0.3],h2);

