%{
Fig. S5 of WW paper.
%}
if ~check_required; return; end

bst_plugin('Load', 'spm12')
addpath sphere_sampling

clear
ft_hastoolbox('SPM')
addpath ./sphere_sampling

% load trials locked to interictal spikes
matfiles = dir('../BST epilepsy EEG/*.mat');
load(['../BST epilepsy EEG/',matfiles(1).name]); % loads D
sr=D.Fsample;
N = length(matfiles) ; 
d=zeros(size(D.data,2),size(D.data,1),N);
for i = 1:N
    load(['../BST epilepsy EEG/',matfiles(i).name]);
    x=D.data;
    d(:,:,i)=double(x)';    
end
t=linspace(-1, 0.5, size(d,1));

% select the EEG channels
idxEEG=[1:19, 23:24,30:37];
d=d(:,idxEEG,:);

% load head model prepared in Brainstorm
load ../from_bst/head_model_epilepsy_EEG_volume_2mm
loc=head_model.GridLoc;
orient=head_model.GridOrient;
g=head_model.Gain;
nlocations=size(g,2)/3;
nsensors=size(g,1);
g=g'; % --> (nlocationsX3) X nsensors
g=reshape(g,3,nlocations,nsensors);
g=permute(g,[2,3,1]);
gain3=g(:,idxEEG,:);
x=loc(:,1);
y=loc(:,2);
z=loc(:,3);



if 1
    % high-pass
    d=nt_demean2(d,t<-0.05);
    hpf=3;
    [B,A]=butter(2,hpf/(sr/2),'high');
    d=filter(B,A,d);
end

% clip to shorter interval
d=d(find(t>-0.5&t<0.2),:,:);
t=t(find(t>-0.5&t<0.2));

% DSS to maximize repeatability
d=nt_demean2(d,t<-0.05);
nt_dss1(d);
[todss,pwr0,pwr1]=nt_dss1(d);
z=nt_mmat(d,todss);


% temporally align (initial alignment was manual)
idxPeak=zeros(size(d,3),1);
for iTrial=1:size(d,3)
    FOCUS=t>-0.03&t<0.01;
    a=xcorr(mean(z(FOCUS,1,:),3),z(FOCUS,1,iTrial));
    [~,idxPeak(iTrial)]=max(a);
end
shift=idxPeak-min(idxPeak);
shift=max(shift)-shift;
dd=zeros(size(d,1)-max(shift),size(d,2),size(d,3));
idx=1:size(dd,1);
for iTrial=1:size(d,3)
    dd(:,:,iTrial)=d(shift(iTrial)+idx,:,iTrial);
end
t=t(median(shift)+idx);

% redo DSS to maximize repeatability
d=nt_demean2(dd,t<-0.05);
nt_dss1(d);
[todss,pwr0,pwr1]=nt_dss1(d);
z=nt_mmat(d,todss);


% rotate to put earliest part on first component
NDSS1=3;
z=z(:,1:NDSS1,:);
c0=nt_cov(mean(z(t>0,:,:),3)); c1=nt_cov(mean(z(t>-0.025&t<-0.01,:,:),3));
[todss2,pwr0,pwr1]=nt_dss0(c0,c1);
zz=nt_mmat(z,todss2);

% redo DSS analyses
if 0
    % bootstrap
    N=1000;
    K=10;
    kbest=[];
    for iIter=1:N
        disp(iIter)
        ntrials=size(dd,3);
        idx=ceil(ntrials*rand(ntrials,1));
        d=dd(:,:,idx);

        % DSS to maximize repeatability
        d=nt_demean2(d,t<-0.05);
        c0=nt_cov(d);
        c1=nt_cov(mean(d,3));
        [todss,pwr0,pwr1]=nt_dss0(c0,c1);
        z=nt_mmat(d,todss);

        % rotate to put earliest part on first component
        NDSS1=3;
        z=z(:,1:NDSS1,:);
        c0=nt_cov(mean(z(t>0,:,:),3)); c1=nt_cov(mean(z(t>-0.03&t<0,:,:),3));
        [todss2,pwr0,pwr1]=nt_dss0(c0,c1);
        zz=nt_mmat(z,todss2);

        % null filters
        F=[todss(:,1:NDSS1)*todss2, todss(:,NDSS1+1:end)]; % combine rotated components with the rest
        F=nt_normcol(F);

        % cost function
        nTarget=1;
        exponent=2;
        [~,~,~,cc]=find_source_orient(nt_mmat(gain3,F),nTarget,exponent);
        cc=log10(cc);

        [~,a]=mink(cc,K);
        kbest(:,iIter)=a;
    end
    save ../tmp/tmp_Fig_S13 kbest N K
else
    load ../tmp/tmp_Fig_S13
end

cf1=zeros(size(x));
cf10=zeros(size(x));
for iIter=1:N
    idx=kbest(1,iIter);
    cf1(idx)=cf1(idx)-1;
    idx=kbest(:,iIter);
    cf10(idx)=cf10(idx)-1;
end



figure(3);clf
set(gcf,'position',[200   597   1200   200])

subplot 141
[cc_collapsed,l_collapsed]=collapse_xyz(cf1/N*100,loc,3);
[min(cc_collapsed(:)), max(cc_collapsed(:))]
x=l_collapsed(:,1)*1000;
y=l_collapsed(:,2)*1000;
z=l_collapsed(:,3)*1000;
scatter3(x,y,z,5,cc_collapsed,'filled');
view(0, 90)
colormap (parula);
set(gca,'color',[1 1 1])
% h=colorbar('eastoutside');
% set(h,'fontsize',14);
% set(get(h,'label'),'string','%', 'fontsize',18);
xlim([-100, 100])
ylim([-100, 100])
zlim([-50, 150])
xlabel('mm'); ylabel('mm');
set(gca,'fontsize', 14, 'box','on');
plot_tweak([0 0.1 -0.03 -0.1])

subplot 143
[cc_collapsed,l_collapsed]=collapse_xyz(cf1/N*100,loc,2);
x=l_collapsed(:,1)*1000;
y=l_collapsed(:,2)*1000;
z=l_collapsed(:,3)*1000;
scatter3(x,y,z,60,cc_collapsed,'filled');
view(0, 0)
colormap (parula);
set(gca,'color',[1 1 1])
% set(gca,'xtick',[],'ytick',[],'ztick',[]);
% set(gca,'box','off')
% set(get(gca,'xaxis'), 'visible','off')
% set(get(gca,'yaxis'), 'visible','off')
% set(get(gca,'zaxis'), 'visible','off')
xlim([29, 60])
ylim([-100, 100])
zlim([84, 116])
xlabel('mm'); 
set(gca,'fontsize', 14, 'box','on');
title('axial')
plot_tweak([0 0.1 -0.04 -0.15])
ylabel('mm');

subplot 142
[cc_collapsed,l_collapsed]=collapse_xyz(cf1/N*100,loc,3);
[min(cc_collapsed(:)), max(cc_collapsed(:))]
x=l_collapsed(:,1)*1000;
y=l_collapsed(:,2)*1000;
z=l_collapsed(:,3)*1000;
scatter3(x,y,z,60,cc_collapsed,'filled');
view(0, 90)
colormap (parula);
% set(gca,'color',[1 1 1])
% set(gca,'xtick',[],'ytick',[],'ztick',[]);
% set(gca,'box','off')
% set(get(gca,'xaxis'), 'visible','off')
% set(get(gca,'yaxis'), 'visible','off')
% set(get(gca,'zaxis'), 'visible','off')
xlim([29, 60])
ylim([-14, 16])
zlim([-50, 150])
xlabel('mm'); 
set(gca,'fontsize', 14, 'box','on');
title('sagittal');
plot_tweak([0 0.1  -0.04 -0.15])
ylabel('mm');



subplot 144
[cc_collapsed,l_collapsed]=collapse_xyz(cf1/N*100,loc,1);
x=l_collapsed(:,1)*1000;
y=l_collapsed(:,2)*1000;
z=l_collapsed(:,3)*1000;
scatter3(x,y,z,60,cc_collapsed,'filled');
view(-90, 0)
colormap (parula);
h=colorbar('eastoutside');
set(h,'fontsize',14, 'ticks',[-25 0], 'ticklabels',{25,0});
set(get(h,'label'),'string','%', 'fontsize',18);
set(gca,'color',[1 1 1])
% set(gca,'xtick',[],'ytick',[],'ztick',[]);
% set(gca,'box','off')
% set(get(gca,'xaxis'), 'visible','off')
% set(get(gca,'yaxis'), 'visible','off')
% set(get(gca,'zaxis'), 'visible','off')
xlim([-100, 100])
ylim([-14, 16])
zlim([84, 117])
xlabel('mm'); ylabel('mm');
set(gca,'fontsize', 14, 'box','on');
title('coronal')



