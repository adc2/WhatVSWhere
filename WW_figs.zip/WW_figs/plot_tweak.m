function plot_tweak(tweak, ax)
%plot_tweak(tweak,ax) - tweak position and size of plot
%
%  tweak: vector of values to adjust plot: [x_shift, y_shift, x_expand, y_expand]
%  ax: handle to axes
%

if nargin<1; error('!'); end
if nargin<2; ax=gca; end

axes(ax)

tweak(end+1:4)=0;
tweak=tweak(:)';
%disp(['old: ', num2str(get(ax,'position'))])
set(ax,'position',get(ax,'position')+tweak);
%disp(['new: ', num2str(get(ax,'position'))])

