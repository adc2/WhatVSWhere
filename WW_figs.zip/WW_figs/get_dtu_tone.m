function D=get_dtu_tone
datapath=['/Users/adc/data/MEG/DTU/ds-eeg-snhl/'];
p=4;
snum=num2str(p,'%03d');
eegname=['sub-',snum,'_task-tonestimuli_eeg.bdf'];
infoname=['sub-',snum,'/eeg/sub-',snum,'_task-tonestimuli_events.tsv'];
% load info
info=tdfread([datapath,infoname]);
tone_events='240';
idxSS=find(strcmp(tone_events,num2cell(info.value,2)));
onsets=info.onset(idxSS);
samples=info.sample(idxSS);
% load EEG
h=sopen([datapath,'sub-',snum,'/eeg/',eegname]);
sr=h.SampleRate;
x=sread(h);
sclose(h);
x=x(:,1:66); % 64 EEG + 2 eye
x=nt_demean(x); 
x=nt_detrend(x,1);    
% cut into trials
T=round(0.2*sr); % 200 ms post-onset
PRE=round(0.06*sr); % 60 ms pre-onset
J=size(x,2);
N=numel(samples);
xx=zeros(T+PRE,J,N);
for iTrial=1:N
    xx(:,:,iTrial)=x(samples(iTrial)-PRE+(0:PRE+T-1),:);
end
D.data=xx;
D.sr=sr;
D.h=h;
