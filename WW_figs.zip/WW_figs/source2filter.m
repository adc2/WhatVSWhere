function GSF=source2filters(GSS,F)
%
%  GSF: source to filter output gain (nsources X nfilters)
%
%  GSS: source to sensor gain (nsources X nsensors)
%  F: filters: (nsensors X nfilters)

GSF=GSS*F;
