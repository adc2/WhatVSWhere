%{
Fig. S5 of WW paper.
%}
if ~check_required; return; end
clear

cameraposition=[4000 -1000 10];
figure(1); clf
set(gcf,'position',[300   597   800   350])

% three sources,
subplot 122

% sensors
nsensors=15; % 
sensor=sensor_positions(nsensors);

% sources
sources=0.4*[ -1,-1; 0 0; 1, -1];

GSS=1./sqdist(sources, sensor); % source to sensor gain

% source and sensor wavforms
s=randn(1000,size(sources,1)); % sources time series
X=s*GSS; % observations

% PCA
topcs=nt_pca0(X); 

% null filters
F=topcs(:,size(sources,1)+1:end);

NNN=500; % density of probe grid
probes=source_grid(NNN);
GPS=source2sensor(probes,sensor);
GPS=reshape(GPS,NNN*NNN,nsensors);

GPF=reshape(GPS*F,NNN,NNN,size(F,2)); % probe to filter gain
bias=mean(abs(GPS),2);
bias=reshape(bias,NNN,NNN);
GPF=bsxfun(@times, GPF, 1./bias);

C=sum(GPF.^2,3);
C=log10(C);
C=zero_outside(C,nan);
hh=surfc(C); shading interp;
set(hh(2), 'levellist',-10:0.5:10)

colormap(gray);
set(gca,'xtick',[],'ytick',[])
set(gca,'clim',[-3 3], 'zlim', [-3 3], 'ztick', [ -2 0 2], 'zticklabel', [.01 1 100])
set(gca, 'cameraposition', cameraposition);
zlabel('cost$(x,y)$', 'interpreter', 'latex', 'fontsize',18)

% one source + ghost
subplot 121

% sensors
nsensors=15; 
sensor=sensor_positions(nsensors)*0.4;

% sources
sources=0.6*[-1,-1];

GSS=1./sqdist(sources, sensor); % source to sensor gain

% source and sensor time series
s=randn(1000,size(sources,1)); 
X=s*GSS; 

% PCA
topcs=nt_pca0(X);

% null filters
F=topcs(:,size(sources,1)+1:end);

NNN=1000; % defines density of source position grid
probes=source_grid(NNN);
GPS=source2sensor(probes,sensor);
GPS=reshape(GPS,NNN*NNN,nsensors);

GPF=reshape(GPS*F,NNN,NNN,size(F,2)); % probe to filter gain
bias=mean(abs(GPS),2);
bias=reshape(bias,NNN,NNN);
GPF=bsxfun(@times, GPF, 1./bias);

C=sum(GPF.^2,3);
C=log10(C);
C=zero_outside(C,nan);
hh=surfc(C); shading interp;
set(hh(2), 'levellist',-10:0.5:10)

colormap(gray);
set(gca,'xtick',[],'ytick',[])
set(gca,'clim',[-3 3], 'zlim', [-3 3], 'ztick', [ -2 0 2], 'zticklabel', [.01 1 100])
set(gca, 'cameraposition', cameraposition)
zlabel('cost$(x,y)$', 'interpreter', 'latex', 'fontsize',18)


