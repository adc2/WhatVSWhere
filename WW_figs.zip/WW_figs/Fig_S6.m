%{
Fig. S6 of WW paper.
%}
if ~check_required; return; end
clear

figure(1); clf
set(gcf,'position',[300   597   1200   220])

clim=[-4 4];

nsensors=5; % 5 sensors
sensors=sensor_positions(nsensors);

% source waveform
s=randn(1000,1); % sources time series
s=[s,s];

% unilateral location
subplot 141
sources=0.4*[-1 -1; -1 -1];
GSS=1./sqdist(sources,sensors);
X=s*GSS; % observations
topcs=nt_pca0(X); %? PCA
F=topcs(:,2:end);

NNN=500; % defines density of source position grid
probes=source_grid(NNN);
G=source2sensor(probes,sensors);
G=reshape(G,NNN*NNN,nsensors);
GG=reshape(abs(G*F),NNN,NNN,4); % gain 
GG=sum(GG.^2,3);

GG=log10(GG);
GG=zero_outside(GG, max(GG(:)));

imagesc([-1 1],[-1 1], GG'); 
set(gca, 'clim',clim)
set(gca, 'fontsize',14);
set(gca,'box','off')
set(get(gca,'xaxis'), 'visible','off')
set(get(gca,'yaxis'), 'visible','off')
drawcross(sources, 'g', 0.2,1, 'linewidth', 2);
hold on
plotsensors(sensors);


% bilateral location
subplot 142
sources=0.4*[-1 -1; 1 -1];
GSS=1./sqdist(sources,sensors);
X=s*GSS; % observations
topcs=nt_pca0(X); %? PCA
F=topcs(:,2:end);

NNN=1000; % defines density of source position grid
probes=source_grid(NNN);
G=source2sensor(probes,sensors);
G=reshape(G,NNN*NNN,nsensors);
GG=reshape(abs(G*F),NNN,NNN,size(F,2)); % gain 
GG=sum(GG.^2,3);

GG=log10(GG);
GG=zero_outside(GG, max(GG(:)));

imagesc([-1 1],[-1 1], GG'); 
set(gca, 'clim',clim)
set(gca, 'fontsize',14);
set(gca,'box','off')
set(get(gca,'xaxis'), 'visible','off')
set(get(gca,'yaxis'), 'visible','off')

drawcross(sources, 'g', 0.2,1, 'linewidth', 2);
colormap gray
hold on
plotsensors(sensors);


subplot 144

probes=source_grid(NNN);
probes=cat(3,probes,repmat(sources(1,:),size(probes,1),1));
C=cost_function2(probes,sensors,F,0);
C=reshape(C,NNN,NNN);
imagesc([-1 1],[-1 1], log10(C)'); 
set(gca, 'clim',clim)
set(gca, 'fontsize',14);
set(gca,'box','off')
set(get(gca,'xaxis'), 'visible','off')
set(get(gca,'yaxis'), 'visible','off')

drawcross(sources, 'g', 0.2,1, 'linewidth', 2);
colormap gray
plot_tweak([0.05 0 0]);
hold on
plotsensors(sensors);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% scanning

if 0
    s=randn(1000,1); % source time series
    s=[s,s]; % same for both positions
    a=[];b=[];
    locations =-0.9:0.005:0.9;
    for iLocation=1:numel(locations)

        % sources to observations
        sources=[-.5 -.5; 1*locations(iLocation) -.5]; % 2 positions
        nsensors=5; % 
        sensors=sensor_positions(nsensors);
        GSS=1./sqdist(sources,sensors);
        X=s*GSS; % observations

        % observations --> null filters
        topcs=nt_pca0(X); %? PCA
        nf=topcs(:,2:end);

        % source to sensor matrix
        NNN=1000; % defines density of source position grid
        probes=source_grid(NNN);
        G0=source2sensor(probes,sensors);

        % single location (unilateral source)
        G=G0;

        % source to null filter output matrix
        G=reshape(G,NNN*NNN,nsensors);
        G=G*nf; 
        G=reshape(G,NNN,NNN,nsensors-1);     
        %G=G.*zerox2(G);
        G=abs(G)+0.00001;

        GGG1=max(G,[],3);
        a(iLocation,1)=min(GGG1(:))/mean(GGG1(:));

        subplot 143
        semilogy(a); drawnow
    end
    save ../tmp/tmp_Fig_S6 a b locations
else
    load ../tmp/tmp_Fig_S6
end

subplot 143
semilogy(locations,a/max(a), 'k')
set(gca,'fontsize',14); 
ylabel('gain at min');
xlim([-1 1])
xlabel('location of second source');
set(gca,'xtick', [-1 0 1], 'ygrid', 'on', 'yminorgrid', 'off');
set(gca, 'fontsize',14);
%ylim([10^-6 0.1])
set(gca,'ytick', [10^-6 10^-4 10^-2 1])
plot_tweak([0.05 0.1 0 -0.1]);

