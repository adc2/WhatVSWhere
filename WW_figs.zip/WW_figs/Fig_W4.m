%{
Fig. 4 of WW paper.
%}
if ~check_required; return; end

clear
%rng(0)

% load head model
switch 3
    case 1 
        load ../from_bst/head_model_15002 % gain matrix and grid coordinates
        head_model=head_model_15002;
    case 2
        load ../from_bst/head_model_volume % gain matrix and grid coordinates
        head_model=head_model_volume;
    case 3
        load ../from_bst/head_model_MEG_sample_introduction_run2_volume_2mm % gain matrix and grid coordinates
    case 4
        load /users/adc/documents/brainstorm/tutorialintroduction/data/subject01/@rawS01_AEF_20131218_02_600Hz/headmodel_vol_os_meg_03.mat
        head_model_volume.Gain=Gain; clear gain
        head_model_volume.GridLoc=GridLoc; clear GridLoc;
        head_model_volume.GridOrient=[];
        head_model=head_model_volume;
end
nt_whoss;
[gain3,gain,locations,orientations]=headmodelparse(head_model); 

% indices of left and right grid points
idxGridL=find(locations(:,2)>=0);
idxGridR=find(locations(:,2)<=0);

% load MEG data
if 0
    D=read_brainstorm_meg;
    save ../tmp/tmp_Fig_W4 D;
else
    load ../tmp/tmp_Fig_W4;
end

% auditory response
meg=D.s; % only standards

% indices of left and right sensors
idxGrad=1:274; % guess based on labels
idxSensorsL=find(D.h.grad.chanpos(idxGrad,2)>=0);
idxSensorsR=find(D.h.grad.chanpos(idxGrad,2)<=0);

if 0
    % filter?
    meg=nt_demean2(meg,1:120);
    hpf=1; % Hz
    [B,A]=butter(2,hpf/(D.sr/2),'high');
    meg=filter(B,A,meg);
    lpf=20; % Hz
    [B,A]=butter(2,lpf/(D.sr/2),'low');
    s=filter(B,A,s);
end

if 1
    % suppress outlier trials
    idx=nt_find_outlier_trials(meg,2.5);
    meg=meg(:,:,idx);
end

figure(1); clf
set(gcf,'position',[200   597   900   240])


% left hemisphere
m=meg(:,idxSensorsL,:);
g3=gain3(idxGridL,idxSensorsL,:);
l=locations(idxGridL,:);
x=l(:,1);
y=l(:,2);
z=l(:,3);

% SCA
toscs=nt_sca(m);
NSCS=100;

% DSS
FOCUS=101:200; % 330 ms
FOCUS=find(D.tauditory>0 & D.tauditory<0.1);
[todss,pwr0,pwr1]=nt_dss1(nt_mmat(m(FOCUS,:,:),toscs(:,1:NSCS)));
if 0
    figure(1); clf;
    plot(pwr1./pwr0, '.-');
end

% null filters
F=toscs(:,1:NSCS)*todss;
if 1
    F=nt_normcol(F);
end

% cost function
nTarget=1;
[~,~,~,cc]=find_source_orient(nt_mmat(g3,F),nTarget);
cc=log10(cc);

h1=subplot(131);
[cc_collapsed,l_collapsed]=collapse_xyz(cc,l,2);
x=l_collapsed(:,1);
y=l_collapsed(:,2);
z=l_collapsed(:,3);
scatter3(x,y,z,10,cc_collapsed,'filled');

colormap (h1, parula);
h=colorbar('southoutside');
set(h,'fontsize',14);
set(get(h,'label'),'string','$log_{10}$(cost)','interpreter','latex', 'fontsize',18);
set(gca,'color',[1 1 1])
set(gca,'xtick',[],'ytick',[],'ztick',[]);
set(gca,'box','off')
set(get(gca,'xaxis'), 'visible','off')
set(get(gca,'yaxis'), 'visible','off')
set(get(gca,'zaxis'), 'visible','off')
colormap(h1,parula);
set(gca,'clim',[-inf 0]);
view(180, 0);
drawnow

%right hemisphere
m=meg(:,idxSensorsR,:);
g3=gain3(idxGridR,idxSensorsR,:);
l=locations(idxGridR,:);
x=l(:,1);
y=l(:,2);
z=l(:,3);

% SCA
toscs=nt_sca(m);
NSCS=100;

% DSS
FOCUS=101:200; % 330 ms
FOCUS=find(D.tauditory>0 & D.tauditory<0.1);
[todss,pwr0,pwr1]=nt_dss1(nt_mmat(m(FOCUS,:,:),toscs(:,1:NSCS)));
if 0
    figure(1); clf;
    plot(pwr1./pwr0, '.-');
end

% null filters
F=toscs(:,1:NSCS)*todss;
if 1
    F=nt_normcol(F);
end

% cost function
nTarget=1;
[~,~,~,cc]=find_source_orient(nt_mmat(g3,F),nTarget);
cc=log10(cc);

% plot
h2=subplot(132);
[cc_collapsed,l_collapsed]=collapse_xyz(cc,l,2);
x=l_collapsed(:,1);
y=l_collapsed(:,2);
z=l_collapsed(:,3);
scatter3(x,y,z,10,cc_collapsed,'filled');
colormap (h1, parula);
h=colorbar('southoutside');
set(h,'fontsize',14);
set(get(h,'label'),'string','$log_{10}$(cost)','interpreter','latex', 'fontsize',18);
set(gca,'color',[1 1 1])
set(gca,'xtick',[],'ytick',[],'ztick',[]);
set(gca,'box','off')
set(get(gca,'xaxis'), 'visible','off')
set(get(gca,'yaxis'), 'visible','off')
set(get(gca,'zaxis'), 'visible','off')
colormap(h2,parula);
set(gca,'clim',[-inf 0]);
view(0, 0);
drawnow


% button press
meg=D.b;

if 0
    % filter?
    meg=nt_demean2(meg,1:120);
    hpf=1; % Hz
    [B,A]=butter(2,hpf/(D.sr/2),'high');
    meg=filter(B,A,meg);
    lpf=20; % Hz
    [B,A]=butter(2,lpf/(D.sr/2),'low');
    s=filter(B,A,s);
end

m=meg;
g3=gain3;
l=locations;
x=l(:,1);
y=l(:,2);
z=l(:,3);

% SCA
toscs=nt_sca(m);
NSCS=100;

% DSS
FOCUS=301:600; % % 500ms before press
FOCUS=find(D.tbutton>-0.5  & D.tbutton<0);
[todss,pwr0,pwr1]=nt_dss1(nt_mmat(m(FOCUS,:,:),toscs(:,1:NSCS)));
if 0
    figure(1); clf;
    plot(pwr1./pwr0, '.-');
end

% null filters
F=toscs(:,1:NSCS)*todss;
if 1
    F=nt_normcol(F);
end

% cost function 
nTarget=1;
[~,~,~,cc]=find_source_orient(nt_mmat(g3,F),nTarget);
cc=log10(cc);

% plot
h3=subplot(133);
[cc_collapsed,l_collapsed]=collapse_xyz(cc,l,3);
x=l_collapsed(:,1);
y=l_collapsed(:,2);
z=l_collapsed(:,3);
scatter3(x,y,z,10,cc_collapsed,'filled');

colormap (h1, parula);
h=colorbar('southoutside');
set(h,'fontsize',14);
set(get(h,'label'),'string','$log_{10}$(cost)','interpreter','latex', 'fontsize',18);
set(gca,'color',[1 1 1])
set(gca,'xtick',[],'ytick',[],'ztick',[]);
set(gca,'box','off')
set(get(gca,'xaxis'), 'visible','off')
set(get(gca,'yaxis'), 'visible','off')
set(get(gca,'zaxis'), 'visible','off')
colormap(h1,parula);
set(gca,'clim',[-inf 0]);
view(0, 90);
drawnow


% alpha
meg=D.meg;

m=meg;
g3=gain3;
l=locations;
x=l(:,1);
y=l(:,2);
z=l(:,3);

% SCA
toscs=nt_sca(m);
NSCS=100;

% DSS
f=10;
[B,A]=nt_filter_peak(f/(D.sr/2), 4); % narrowband filter
[c0,c1]=nt_bias_filter(meg*toscs(:,1:NSCS),B,A);
if 0
    % contrast with wider bandpass, else with all 
    [B,A]=nt_filter_peak(f/(D.sr/2), 2);
    [~,c0]=nt_bias_filter(meg*toscs(:,1:NSCS),B,A);
end
[todss,pwr0,pwr1]=nt_dss0(c0,c1);

% null filters
F=toscs(:,1:NSCS)*todss;
if 1
    F=nt_normcol(F);
end

% cost function
nTarget=11;
[~,~,~,cc]=find_source_orient(nt_mmat(g3,F),nTarget);


figure(2); clf
set(gcf,'position',[200   597   900   160])

% sagittal
subplot 131
cc=log10(cc);
[cc_collapsed,l_collapsed]=collapse_xyz(cc,l,2);
x=l_collapsed(:,1);
y=l_collapsed(:,2);
z=l_collapsed(:,3);
scatter3(x,y,z,10,cc_collapsed,'filled');

colormap (parula);
set(gca,'color',[1 1 1])
set(gca,'xtick',[],'ytick',[],'ztick',[]);
set(gca,'box','off')
set(get(gca,'xaxis'), 'visible','off')
set(get(gca,'yaxis'), 'visible','off')
set(get(gca,'zaxis'), 'visible','off')
view(0,0)
set(gca,'clim',[-inf 0]);
plot_tweak([0 0 0 0])

% axial
subplot 132
[cc_collapsed,l_collapsed]=collapse_xyz(cc,l,3);
x=l_collapsed(:,1);
y=l_collapsed(:,2);
z=l_collapsed(:,3);
scatter3(x,y,z,10,cc_collapsed,'filled');

colormap (parula);
% h=colorbar('southoutside');
% set(h,'fontsize',14);
% set(get(h,'label'),'string','$log_{10}$(cost)','interpreter','latex', 'fontsize',18);
set(gca,'color',[1 1 1])
set(gca,'xtick',[],'ytick',[],'ztick',[]);
set(gca,'box','off')
set(get(gca,'xaxis'), 'visible','off')
set(get(gca,'yaxis'), 'visible','off')
set(get(gca,'zaxis'), 'visible','off')
view(0,90)
set(gca,'clim',[-inf 0]);
plot_tweak([-0.01 0 -0.02 0.1])

% coronal
subplot 133
[cc_collapsed,l_collapsed]=collapse_xyz(cc,l,1);
x=l_collapsed(:,1);
y=l_collapsed(:,2);
z=l_collapsed(:,3);
scatter3(x,y,z,10,cc_collapsed,'filled');

colormap (parula);
h=colorbar('eastoutside');
set(h,'fontsize',14);
set(get(h,'label'),'string','$log_{10}$(cost)','interpreter','latex', 'fontsize',18);
set(h,'ticks',[-1.5 -1 -0.5 0])
set(gca,'color',[1 1 1])
set(gca,'xtick',[],'ytick',[],'ztick',[]);
set(gca,'box','off')
set(get(gca,'xaxis'), 'visible','off')
set(get(gca,'yaxis'), 'visible','off')
set(get(gca,'zaxis'), 'visible','off')
view(-90,0)
set(gca,'clim',[-inf 0]);
plot_tweak([ -.04 0 0.05 0])

