%{
Fig. 3 of WW paper.
%}
if ~check_required; return; end

clear
%rng(0)
figure(1); clf
set(gcf,'position',[200   597   1200   200])


load ../from_bst/head_model_15002; % from brainstem tutorial
head_model=head_model_15002; % gain matrix and grid coordinates
[gain3,gain,loc,orient]=headmodelparse(head_model); 
x=loc(:,1);
y=loc(:,2);
z=loc(:,3);
[~,idx]=sort(loc(:,2)); % leftmost locations (for visual clarity)


% ground truth for single dipole
idxSource=idx(1);
ground_truth=ones(size(gain,1),1);
ground_truth(idxSource)=0;

h1=subplot(151);
scatter3(x,y,z, 60, ground_truth); view(0, 0);
set(gca,'xtick',[],'ytick',[],'ztick',[]);
set(gca,'box','off')
set(get(gca,'xaxis'), 'visible','off')
set(get(gca,'yaxis'), 'visible','off')
set(get(gca,'zaxis'), 'visible','off')
plot_tweak([0, 0.3, 0,-0.3]);
colormap(h1,'gray');
set(gca,'clim',[0 1.1]);

% estimate source position for single dipole

% source and sensor waveforms
s=randn(10000,1); 
s=repmat(s,1,numel(idxSource));
X=s*gain(idxSource,:); % sensor waveforms

% null filters
topcs=nt_pca0(X);
F=topcs;

% cost function
exponent=2;
nTarget=1;
[~,~,cost]=find_source(gain*F,nTarget,exponent);

% plot
h2=subplot(152);
cost=cost/max(cost(:));
cost=log10(cost);
scatter3(x,y,z, 60, cost, 'filled'); 

h=colorbar('southoutside');
set(h,'fontsize',14);
set(get(h,'label'),'string','$log_{10}$(cost)','interpreter','latex', 'fontsize',18);
view(0, 0);
set(gca,'xtick',[],'ytick',[],'ztick',[]);
set(gca,'box','off')
set(get(gca,'xaxis'), 'visible','off')
set(get(gca,'yaxis'), 'visible','off')
set(get(gca,'zaxis'), 'visible','off')
colormap (h2,parula)
set(gca,'clim',[-30 0]);


% ground truth for multiple dipoles
idxSource=idx(1:10);
ground_truth=ones(size(gain,1),1);
ground_truth(idxSource)=0;

h2=subplot(153);
scatter3(x,y,z, 20, ground_truth); view(0, 0);

set(gca,'color',[1 1 1])
set(gca,'xtick',[],'ytick',[],'ztick',[]);
set(gca,'box','off')
set(get(gca,'xaxis'), 'visible','off')
set(get(gca,'yaxis'), 'visible','off')
set(get(gca,'zaxis'), 'visible','off')
colormap(h2,'gray');
set(gca,'clim',[0 1.1]);
drawnow

% source and sensor waveforms
s=randn(10000,numel(idxSource)); %source waveform
s=nt_normcol(nt_pca(s)); % perfectly decorrelated
if 0
    s=0.001*s+repmat(s(:,1),1,numel(idxSource)); % introduce correlation
end
X=s*gain(idxSource,:); % sensor waveforms

% null filters
topcs=nt_pca0(X);
F=topcs;

% cost function
exponent=2;
nTarget=numel(idxSource);
[~,~,cost]=find_source(gain*F,nTarget,exponent);

% plot
h3=subplot(154);
cost=cost/max(cost(:));
cost=log10(cost);
scatter3(x,y,z, 30, cost, 'filled'); 

h=colorbar('southoutside');
set(h,'fontsize',14);
set(get(h,'label'),'string','$log_{10}$(cost)','interpreter','latex', 'fontsize',18);
view(0, 0);
set(gca,'color',[1 1 1])
set(gca,'xtick',[],'ytick',[],'ztick',[]);
set(gca,'box','off')
set(get(gca,'xaxis'), 'visible','off')
set(get(gca,'yaxis'), 'visible','off')
set(get(gca,'zaxis'), 'visible','off')
colormap (h3,parula)
set(gca,'clim',[-30 0]);
plot_tweak([0, 0.3, 0,-0.3],h2);
