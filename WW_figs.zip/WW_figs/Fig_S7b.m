% 
% W&W
% 
% analyze Brainstorm tutorial data
clear
%rng(0)

figure(1); clf
set(gcf,'position',[200   597   1200   200])

load ./head_model_15002 % gain matrix and grid coordinates
head_model=head_model_15002;
%load ./brainstorm/head_model % gain matrix and grid coordinates (45006 locations)
[gain3,gain,loc,orient]=headmodelparse(head_model); 
x=loc(:,1);
y=loc(:,2);
z=loc(:,3);

[~,idx]=sort(loc(:,2)); % leftmost locations (for visual clarity)

% source is single dipole
idxSource=idx(1);

s=randn(10000,1); %source waveform
s=repmat(s,1,numel(idxSource));

SNRs=10.^[-1:20];
depth=zeros(size(SNRs));
depth2=zeros(size(gain,1),numel(SNRs));
for iSNR=1:numel(SNRs)  
    g=gain+randn(size(gain))*sqrt(mean(gain(:).^2))/SNRs(iSNR);
    % null filters
    X=s*g(idxSource,:); % sensor waveforms
    topcs=nt_pca0(X);

    F=topcs;
    exponent=2;
    nTarget=1;
    [~,~,C]=find_source(gain*F,nTarget,exponent);
    depth(iSNR)=min(C(:));
    depth2(:,iSNR)=sort(C);
end

subplot 151
loglog(SNRs,depth, '.-k');
set(gca,'xtick',[1 10^10 10^20]);
set(gca,'fontsize',14)
set(gca,'ytick',[10^-30 10^-20 10^-10 1]);
xlabel('SNR(gain)'); ylabel('cost at min');
set(gca,'xgrid','on','ygrid','on');
plot_tweak([0.02, 0.2, -0.02,-0.2]);


subplot 152

% difference between each gain vector and the closest of the other gain vectors
d=1-abs(nt_cov(nt_normcol(gain')))/size(gain,2);
d=sqrt(d);
d=d+eye(size(d,1))*max(d(:));
dmin=min(d);

% plot cumulative histogram
[a,b]=hist(dmin(:),30);
b(1)=min(d(:));
semilogx(b, cumsum(a)/sum(a)*100, '.-k');
set(gca,'xtick',[0.01 0.1 1]);
xlim([0.01 1]);
set(gca,'fontsize',14)
set(gca,'ytick',[0 50 100]);
xlabel({'normalized distance'; 'between gain vectors'}); ylabel('cumulated (%)');
set(gca,'xgrid','on','ygrid','on');
plot_tweak([0.02, 0.2, 0,-0.2]);


% scan source space (constrained), synthesize data, estimate source
% position, gather statistics of errors and distance of alternative
% solutions

if 0
    rng('default');
    idxSource=randperm(size(gain,1));
    s=randn(10000,1); %source waveform
    samplesize=1000;
    nerrors=0; iError=1; errors=[]; a=[]; b=[];
    for iSource=1:samplesize
        X=s*gain(idxSource(iSource),:);
        topcs=nt_pca0(X);
        F=topcs;
        nTarget=1;
        exponent=2;
        [idx,val,orient,cc]=find_source_orient(nt_mmat(gain3,F),nTarget,exponent);
        if idx~=idxSource(iSource); 
            nerrors=nerrors+1;
            disp([iSource, nerrors]);
            errors(iError)=sqrt(sqdist(loc(idx,:),loc(idxSource(iSource),:)));
            disp(errors(iError));
            iError=iError+1;
        end
        N=6;
        [~,idxBestCandidates]=mink(cc,N);
        a(iSource,:)=cc(idxBestCandidates);
        b(iSource,:)=sqrt(sqdist(loc(idxSource(iSource),:),loc(idxBestCandidates(:),:)));
        semilogy(b(iSource,1),a(iSource,1), '.k'); hold on;
        semilogy(b(iSource,2),a(iSource,2), '.b'); hold on;
        semilogy(b(iSource,3),a(iSource,3), '.g'); hold on;
        semilogy(b(iSource,4),a(iSource,4), '.r'); hold on;
        semilogy(b(iSource,5),a(iSource,5), '.m'); hold on;
        semilogy(b(iSource,6),a(iSource,6), '.y'); hold on;
        drawnow
    end
    save tmp_Fig_S7b errors a b
else
    load tmp_Fig_S7b
end

if 0
    load tmp_Fig_S7b
    % same, with noise on gain vectors
    SNR=10;
    g=gain+randn(size(gain))*sqrt(mean(gain(:).^2))/SNR;

    rng('default');
    idxSource=randperm(size(gain,1));
    s=randn(10000,1); %source waveform
    samplesize=1000;
    nerrors=0; iError=1; errors2=[]; a2=[]; b2=[];
    for iSource=1:samplesize
        X=s*g(idxSource(iSource),:);
        topcs=nt_pca0(X);
        F=topcs;
        nTarget=1;
        exponent=2;
        [idx,val,orient,cc]=find_source_orient(nt_mmat(gain3,F),nTarget,exponent);
        if idx~=idxSource(iSource); 
            nerrors=nerrors+1;
            disp([iSource, nerrors]);
            errors2(iError)=sqrt(sqdist(loc(idx,:),loc(idxSource(iSource),:)));
            disp(errors2(iError));
            iError=iError+1;
        end
        N=6;
        [~,idxBestCandidates]=mink(cc,N);
        a2(iSource,:)=cc(idxBestCandidates);
        b2(iSource,:)=sqrt(sqdist(loc(idxSource(iSource),:),loc(idxBestCandidates(:),:)));
        semilogy(b2(iSource,1),a2(iSource,1), '.k'); hold on;
        semilogy(b2(iSource,2),a2(iSource,2), '.b'); hold on;
        semilogy(b2(iSource,3),a2(iSource,3), '.g'); hold on;
        semilogy(b2(iSource,4),a2(iSource,4), '.r'); hold on;
        semilogy(b2(iSource,5),a2(iSource,5), '.m'); hold on;
        semilogy(b2(iSource,6),a2(iSource,6), '.y'); hold on;
        drawnow
    end
    
    save tmp_Fig_S7b errors a b errors2 a2 b2
else
    load tmp_Fig_S7b
end

subplot 153
aa=a(:,3:6); bb=b(:,3:6);
semilogy(bb(:)*1000,aa(:), '.g', 'markersize',5); hold on;
semilogy(b(:,2)*1000,a(:,2), '.r', 'markersize',4); hold on;
semilogy(b(:,1)*1000,a(:,1), '.k', 'markersize',5); hold on;
legend('3-6th best','2nd best','best', 'location','southeast'); legend boxoff
xlim([-1,20]); ylim([10^-5 1])
set(gca,'fontsize',14); 
set(gca,'ytick',[10^-4 10^-2 1]);
set(gca,'xgrid','on','ygrid','on','yminorgrid','off');
xlabel('spatial distance (mm)'); ylabel('cost');
plot_tweak([0.03, 0.2, 0,-0.3]);
title('SNR(gain) = \infty', 'interpreter','tex')

subplot 154
aa=a2(:,3:6); bb=b2(:,3:6);
semilogy(bb(:)*1000,aa(:), '.g', 'markersize',5); hold on;
semilogy(b2(:,2)*1000,a2(:,2), '.r', 'markersize',4); hold on;
semilogy(b2(:,1)*1000,a2(:,1), '.k', 'markersize',5); hold on;
legend('3-6th best','2nd best','best', 'location','southeast'); legend boxoff
%xlim([-1,20]); 
ylim([10^-5 1])
set(gca,'fontsize',14); 
set(gca,'ytick',[10^-4 10^-2 1]);
set(gca,'xgrid','on','ygrid','on','yminorgrid','off');
xlabel('spatial distance (mm)'); ylabel('cost');
plot_tweak([0.06, 0.2, 0,-0.3]);
title('SNR(gain) = 10')
% 
% subplot 154
% semilogy(depth2);
