%{
Fig. S8 of WW paper.
%}
if ~check_required; return; end
clear
%rng(0)

figure(1); clf
set(gcf,'position',[200   597   1200   200])

load ../from_bst/head_model_15002 % gain matrix and grid coordinates
head_model=head_model_15002;
%load ./brainstorm/head_model % gain matrix and grid coordinates (45006 locations)
[gain3,gain,loc,orient]=headmodelparse(head_model); 
x=loc(:,1);
y=loc(:,2);
z=loc(:,3);

[~,idx]=sort(head_model.GridLoc(:,2)); % leftmost locations

% source is dipole pair
idxSource=idx([1 2]);

% ground truth
h1=subplot(151);
ground_truth=ones(size(gain,1),1);
ground_truth(idxSource)=0;
scatter3(x,y,z, 60, ground_truth); view(0, 0);
set(gca,'color',[1 1 1])
set(gca,'xtick',[],'ytick',[],'ztick',[]);
set(gca,'box','off')
set(get(gca,'xaxis'), 'visible','off')
set(get(gca,'yaxis'), 'visible','off')
set(get(gca,'zaxis'), 'visible','off')
colormap(h1,'gray');
set(gca,'clim',[0 1.1]);
plot_tweak([0, 0.3, 0,-0.3]);

% null filters
s=randn(10000,1); %source waveform
s=repmat(s,1,numel(idxSource));
X=s*gain(idxSource,:); % sensor waveforms
topcs=nt_pca0(X);

F=topcs;
exponent=2;
nTarget=1;
[~,~,C]=find_source(gain*F,nTarget,exponent);

h2=subplot(152);
C=C/max(C(:));
C=log10(C);
scatter3(x,y,z, 60, C, 'filled'); 
h=colorbar('southoutside');
set(h,'fontsize',14);
set(get(h,'label'),'string','$log_{10}$(cost)','interpreter','latex', 'fontsize',18);
view(0, 0);
set(gca,'color',[1 1 1])
set(gca,'xtick',[],'ytick',[],'ztick',[]);
set(gca,'box','off')
set(get(gca,'xaxis'), 'visible','off')
set(get(gca,'yaxis'), 'visible','off')
set(get(gca,'zaxis'), 'visible','off')
colormap (h2,parula)
set(gca,'clim',[-2 0]);


% two-source model

N=1000;
idxSelected=idx(1:N);  % leftmost
gain_selected=gain(idxSelected,:);
nTarget=1;
[loc, val, c, C]=find_source_pair(gain_selected*F,nTarget);
c=c/max(c(:));
c=log10(c);

h3=subplot (153)
scatter3(x,y,z, 60, ones(size(gain,1),1)*max(c(:)*257/256), 'filled'); 
hold on
scatter3(x(idxSelected),y(idxSelected),z(idxSelected), 60, c, 'filled'); 
h=colorbar('southoutside');
set(h,'fontsize',14);
set(get(h,'label'),'string','$log_{10}$(cost)','interpreter','latex', 'fontsize',18);
view(0, 0);
set(gca,'color',[1 1 1])
set(gca,'xtick',[],'ytick',[],'ztick',[]);
set(gca,'box','off')
set(get(gca,'xaxis'), 'visible','off')
set(get(gca,'yaxis'), 'visible','off')
set(get(gca,'zaxis'), 'visible','off')



parula0=parula;
parula0(end,:)=[1 1 1]*0.9;
colormap (h3,parula0)


% real MEG
load ../tmp/tmp_Fig_S7
target0=target;


% null filters
%idxSource=idxSource(1);
target=nt_pca(target);
target=nt_normcol(target(:,1));
target=repmat(target,[1,numel(idxSource),1]);
T=nt_mmat(target,gain(idxSource,:)); % sensor waveforms for target
B=background;
T=T*sqrt(ttb)*sqrt(mean(B(:).^2))/sqrt(mean(T(:).^2));

X=B+T;

[todss,pwr0,pwr1]=nt_dss1(X);
if 0
    figure(10); clf; plot(pwr1./pwr0, '.-');
    figure(1)
end
F=todss;

N=1000;
idxSelected=idx(1:N);  % leftmost
gain_selected=gain(idxSelected,:);
nTarget=1;
[loc, val, c, C]=find_source_pair(gain_selected*F,nTarget);
c=c/max(c(:));
c=log10(c);

h4=subplot(154);
scatter3(x,y,z, 60, ones(size(gain,1),1)*max(c(:)*257/256), 'filled'); 
hold on
scatter3(x(idxSelected),y(idxSelected),z(idxSelected), 60, c, 'filled'); 
h=colorbar('southoutside');
set(h,'fontsize',14);
set(get(h,'label'),'string','$log_{10}$(cost)','interpreter','latex', 'fontsize',18);
view(0, 0);
set(gca,'color',[1 1 1])
set(gca,'xtick',[],'ytick',[],'ztick',[]);
set(gca,'box','off')
set(get(gca,'xaxis'), 'visible','off')
set(get(gca,'yaxis'), 'visible','off')
set(get(gca,'zaxis'), 'visible','off')
colormap(h4,parula0);
set(gca,'clim',[-2 0]);

