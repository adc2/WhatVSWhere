%{
Fig. S9 of WW paper.
%}
if ~check_required; return; end

clear
addpath sphere_sampling
%rng(0)

figure(1); clf
set(gcf,'position',[200   597   1200   250])

load ../from_bst/head_model_15002 % gain matrix and grid coordinates
head_model=head_model_15002;
%load ./brainstorm/head_model % gain matrix and grid coordinates (45006 locations)
[gain3,gain,loc,orient]=headmodelparse(head_model); 
x=loc(:,1);
y=loc(:,2);
z=loc(:,3);

[~,idx]=sort(head_model.GridLoc(:,2)); % leftmost locations

% source is dipole
idxSource=idx([1]);

% null filters
s=randn(10000,1); %source waveform
s=repmat(s,1,numel(idxSource));
X=s*gain(idxSource,:); % sensor waveforms
topcs=nt_pca0(X);
F=topcs;

GSLOF(:,:,1)=gain3(:,:,1)*F; GSLOF(:,:,2)=gain3(:,:,2)*F; GSLOF(:,:,3)=gain3(:,:,3)*F;

F=topcs;
nTarget=1;
[~,~,~,C]=find_source_orient(GSLOF,nTarget);

subplot 141

C=C/max(C(:));
C=log10(C);
scatter3(x,y,z, 60, C, 'filled'); 
h=colorbar('southoutside');
set(h,'fontsize',14);
set(get(h,'label'),'string','$log_{10}$(cost)','interpreter','latex', 'fontsize',18);
view(0, 0);
set(gca,'color',[1 1 1])
set(gca,'xtick',[],'ytick',[],'ztick',[]);
set(gca,'box','off')
set(get(gca,'xaxis'), 'visible','off')
set(get(gca,'yaxis'), 'visible','off')
set(get(gca,'zaxis'), 'visible','off')
colormap parula
set(gca,'clim',[-4 0]);

if 0
    rng('default');
    idxSource=randperm(size(gain,1));
    s=randn(10000,1); %source waveform
    samplesize=1000;
    nerrors=0; iError=1; errors=[]; a=[]; b=[];
    for iSource=1:samplesize
        X=s*gain(idxSource(iSource),:);
        topcs=nt_pca0(X);
        F=topcs;
        nTarget=1;
        exponent=2;
        [idx,val,orient,cc]=find_source_orient(nt_mmat(gain3,F),nTarget,exponent);
        if idx~=idxSource(iSource); 
            nerrors=nerrors+1;
            disp([iSource, nerrors]);
            errors(iError)=sqrt(sqdist(loc(idx,:),loc(idxSource(iSource),:)));
            disp(errors(iError));
            iError=iError+1;
        end
        N=6;
        [~,idxBestCandidates]=mink(cc,N);
        a(iSource,:)=cc(idxBestCandidates);
        b(iSource,:)=sqrt(sqdist(loc(idxSource(iSource),:),loc(idxBestCandidates(:),:)));
        semilogy(b(iSource,1),a(iSource,1), '.k'); hold on;
        semilogy(b(iSource,2),a(iSource,2), '.b'); hold on;
        semilogy(b(iSource,3),a(iSource,3), '.g'); hold on;
        semilogy(b(iSource,4),a(iSource,4), '.r'); hold on;
        semilogy(b(iSource,5),a(iSource,5), '.m'); hold on;
        semilogy(b(iSource,6),a(iSource,6), '.y'); hold on;
        drawnow
    end
    save ../tmp/tmp_Fig_S7b errors a b
else
    load ../tmp/tmp_Fig_S7b
end

if 0
    load ../tmp/tmp_Fig_S7b
    % same, with noise on gain vectors
    SNR=10;
    g=gain+randn(size(gain))*sqrt(mean(gain(:).^2))/SNR;

    rng('default');
    idxSource=randperm(size(gain,1));
    s=randn(10000,1); %source waveform
    samplesize=1000;
    nerrors=0; iError=1; errors2=[]; a2=[]; b2=[];
    for iSource=1:samplesize
        X=s*g(idxSource(iSource),:);
        topcs=nt_pca0(X);
        F=topcs;
        nTarget=1;
        exponent=2;
        [idx,val,orient,cc]=find_source_orient(nt_mmat(gain3,F),nTarget,exponent);
        if idx~=idxSource(iSource); 
            nerrors=nerrors+1;
            disp([iSource, nerrors]);
            errors2(iError)=sqrt(sqdist(loc(idx,:),loc(idxSource(iSource),:)));
            disp(errors2(iError));
            iError=iError+1;
        end
        N=6;
        [~,idxBestCandidates]=mink(cc,N);
        a2(iSource,:)=cc(idxBestCandidates);
        b2(iSource,:)=sqrt(sqdist(loc(idxSource(iSource),:),loc(idxBestCandidates(:),:)));
        semilogy(b2(iSource,1),a2(iSource,1), '.k'); hold on;
        semilogy(b2(iSource,2),a2(iSource,2), '.b'); hold on;
        semilogy(b2(iSource,3),a2(iSource,3), '.g'); hold on;
        semilogy(b2(iSource,4),a2(iSource,4), '.r'); hold on;
        semilogy(b2(iSource,5),a2(iSource,5), '.m'); hold on;
        semilogy(b2(iSource,6),a2(iSource,6), '.y'); hold on;
        drawnow
    end
    
    save ../tmp/tmp_Fig_S7b errors a b errors2 a2 b2
else
    load ../tmp/tmp_Fig_S7b
end

h2=subplot(142);
aa=a(:,3:6); bb=b(:,3:6);
semilogy(bb(:)*1000,aa(:), '.g', 'markersize',5); hold on;
semilogy(b(:,2)*1000,a(:,2), '.r', 'markersize',4); hold on;
semilogy(b(:,1)*1000,a(:,1), '.k', 'markersize',5); hold on;
legend('3-6th best','2nd best','best', 'location','southeast'); legend boxoff
xlim([-1,20]); ylim([10^-5 1])
set(gca,'fontsize',14); 
set(gca,'ytick',[10^-4 10^-2 1]);
set(gca,'xgrid','on','ygrid','on','yminorgrid','off');
xlabel('spatial distance (mm)'); ylabel('cost');
title('SNR(gain) = \infty', 'interpreter','tex')

drawnow
h3=subplot(143);
aa=a2(:,3:6); bb=b2(:,3:6);
semilogy(bb(:)*1000,aa(:), '.g', 'markersize',5); hold on;
semilogy(b2(:,2)*1000,a2(:,2), '.r', 'markersize',4); hold on;
semilogy(b2(:,1)*1000,a2(:,1), '.k', 'markersize',5); hold on;
legend('3-6th best','2nd best','best', 'location','southeast'); legend boxoff
%xlim([-1,20]); 
ylim([10^-5 1])
set(gca,'fontsize',14); 
set(gca,'ytick',[10^-4 10^-2 1]);
set(gca,'xgrid','on','ygrid','on','yminorgrid','off');
xlabel('spatial distance (mm)'); ylabel('cost');
title('SNR(gain) = 10')
drawnow

idxSource=idx(1);

s=randn(10000,1); %source waveform
s=repmat(s,1,numel(idxSource));

SNRs=10.^[-1:20];
depth=zeros(size(SNRs));
depth2=zeros(size(gain,1),numel(SNRs));
for iSNR=1:numel(SNRs)  
    g=gain+randn(size(gain))*sqrt(mean(gain(:).^2))/SNRs(iSNR);
    % null filters
    X=s*g(idxSource,:); % sensor waveforms
    topcs=nt_pca0(X);

    F=topcs;
    exponent=2;
    nTarget=1;
    [~,~,C]=find_source(gain*F,nTarget,exponent);
    depth(iSNR)=min(C(:));
    depth2(:,iSNR)=sort(C);
end

h4=subplot(144);
loglog(SNRs,depth, '.-k');
set(gca,'xtick',[1 10^10 10^20]);
set(gca,'fontsize',14)
set(gca,'ytick',[10^-30 10^-20 10^-10 1]);
xlabel('SNR(gain)'); ylabel('cost at min');
set(gca,'xgrid','on','ygrid','on');


plot_tweak( [0.02, 0.2, 0,-0.3], h2);
plot_tweak([0.04, 0.2, 0,-0.3],h3);
plot_tweak([0.06, 0.2, 0,-0.3],h4);


