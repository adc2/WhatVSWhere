%function [idx,val,orient,cc]=find_source_orient(GLF3D,nTarget,idxClosest)
function [idx,val,orient,cc]=find_source_orient(GLF3D,nTarget)
%[idx,val,orient,cc]=find_source_orient(GLF3D,nTarget,idxClosest) - find index and orientation of source 
%
%   idx: indices of source pair
%   val: value at minimum
%   orient: orientation vector (3 X 1)
%   cc: value at best orientation for all locations
%
%   GLF3D: location-to-filter gain for null filters (nlocations X nfilters X 3)
%   nTarget: number of target components [default: 1]
%   idxClosest: indices of closest neighbors to each location

if nargin<1; error('!'); end
if nargin<2; nTarget=1; end

GLF3D_full=GLF3D;
GLF3D=GLF3D_full(:,nTarget+1:end,:);

nfilters=size(GLF3D,2);
nlocations=size(GLF3D,1);
nfilters_full=size(GLF3D_full,2);


% sample 3D orientations uniformly
norientations=100;
oGrid=SpiralSampleSphere(norientations); % norientations X 3
dd=1-oGrid*oGrid'; % inter-orientation distances

% gain for each orientation (3 --> norientations)
GLFO=reshape(GLF3D,[nlocations*nfilters,3])*oGrid';
GLFO=reshape(GLFO,[nlocations,nfilters,norientations]);
GLFO=permute(GLFO,[1 3 2]);  % nlocations X norientations X nfilters

% evaluate cost at every location/orientation
cost=cost_function5(reshape(GLFO,[nlocations*norientations,nfilters]), 1);
cost=reshape(cost,nlocations,norientations);
    
if 0
for iLoc=1:nlocations
    figure(1); clf;
    scatter3(oGrid(:,1),oGrid(:,2),oGrid(:,3),60,log10(cost(iLoc,:)),'filled'); 
    drawnow
end
end


% gain for best orientation at each location
[~,iBestOrientation]=min(cost,[],2);
GLF=zeros(nlocations,nfilters);
for iLoc=1:nlocations
    
    % the cost function of orientation is bipolar, we need to chose one pole
    otherSide=find(dd(iBestOrientation(iLoc),:)>1);
    cost(iLoc,otherSide)=inf; % zap orientations opposite to best 
    
    % choose 4 best orientations
    [~,idxBestFew]=mink(cost(iLoc,:),4);
    oBestFew=oGrid(idxBestFew,:);
    cBestFew=cost(iLoc,idxBestFew);
    cBestFew=cBestFew+eps;

    % interpolate orientation 
    oBetter=oBestFew(1,:)/cBestFew(1)+oBestFew(2,:)/cBestFew(2)+oBestFew(3,:)/cBestFew(3);
    oBetter=oBetter/sqrt(sum(oBetter.^2));
    
    % best location to filter gain
    GLF(iLoc,:)=reshape(GLF3D(iLoc,:,:),nfilters,3) * oBetter';
    GLF_full(iLoc,:)=reshape(GLF3D_full(iLoc,:,:),nfilters_full,3) * oBetter'; % --> bias
end

% set to zero the gain samples at zero crossings
% thresh=0; % set to zero any sample with at least thresh neighbors of opposite sign
% mask=zerox3(GLF,idxClosest(:,:),thresh);
% disp(mean(mask(:)));
% figure(1); plot(sum(1-mask,2)); pause
%GLF=GLF.*mask;

% cost at each location, find lowest
val=inf;
for iLoc=1:nlocations
    
    cc(iLoc)=cost_function5(GLF(iLoc,:),1);        

    % normalize by cost averaged over full filter matrix
    g2=GLF_full(iLoc,:);
    bias=cost_function5(reshape(g2,1,nfilters_full),1);      
    cc(iLoc)=cc(iLoc)/bias;

    if cc(iLoc)<val
        val=cc(iLoc);
        idx=iLoc;
        orient=oBetter;
    end
end
    