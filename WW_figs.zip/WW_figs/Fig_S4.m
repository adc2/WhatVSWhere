%{
Fig. S4 of WW paper.
%}
if ~check_required; return; end


clear

figure(1); clf
set(gcf,'position',[300   597   1200   300])

% colors
if 0
    % lighter
    blue = [114 147 203]./255;
    red = [211 94 96]./255;
    black = [128 133 133]./255;
    green = [132 186 91]./255;
    brown = [171 104 87]./255;
    purple = [144 103 167]./255;
else 
    % darker
    blue = [57 106 177]./255;
    red = [204 37 41]./255;
    black = [83 81 84]./255;
    green = [62 150 81]./255;
    brown = [146 36 40]./255;
    purple = [107 76 154]./255;
end
cl=[blue;red;black;green;brown;purple];

% sensors
nsensors=6; 
sensors=sensor_positions(nsensors);

% sources
N=9; % --> nsources=N^2
sources=source_grid(N)*0.5;


GSS=1./sqdist(sources, sensors); % source to sensor gain

% ground truth
h1=subplot(1,3,1);
NNN=400;
A=ones(NNN,NNN)*10;
A=zero_outside(A);
image([-1,1],[-1,1],256-A); % faint gray background
colormap(h1,'gray');

% draw sources
cl=get(gca,'colororder');
for iSrc=1:size(sources,1)
    drawcross(sources(iSrc,:),cl(mod(iSrc-1,7)+1,:), 0.04, [], 'linewidth', 4)
end
hold on
plotsensors(sensors);


set(gca,'box','off')
set(get(gca,'xaxis'), 'visible','off')
set(get(gca,'yaxis'), 'visible','off')


% source time series
s=zeros(11000,size(sources,1));
for iSource=1:size(sources,1)
    s(100+100*(iSource-1)+1,iSource)=1;
end
[B,A]=butter(1,1/200,'low');
s=filter(B,A,s);
s=s.*randn(size(s));

% sensor time series
X=s*GSS; 
X=X+0.00001*randn(size(X)); % add a bit of noise to avoid rank-deficient data

% plot source waveforms
subplot 232
plot(s)

set(gca,'ytick',[], 'xtick',[]);
ylim([-0.1 0.1]);
xlim([0 1000])
title('sources');
set(gca,'fontsize',14);
plot_tweak([0 0 0 -0.1])

% plot sensor waveforms
subplot 235
plot(X)

set(gca,'ytick',[], 'xtick',[0 500 1000], 'xticklabel', [0 0.5 1]);
ylim([-0.5, 0.5])
xlim([0 1000])
xlabel('time (s)');
title('sensors')
set(gca,'fontsize',14);
plot_tweak([0 0.1 0 -0.1])

% DSS repeated for each pulse
c0=nt_cov(X);
for iSource=1:size(sources,1)
    c1=nt_cov(X(100+100*(iSource-1)+(1:100),:));
    [todss,pwr0,pwr1]=nt_dss0(c0,c1);
    FF{iSource}=todss(:,2:end);
end

% probe grid
NNN=400; 
probes=source_grid(NNN);
GPS=1./sqdist(probes,sensors); % probe to sensor gain

subplot 133
A=ones(NNN,NNN)*10;
A=zero_outside(A);
image([-1,1],[-1,1],256-A); % faint gray background
colormap(h1,'gray');

% estimate, draw source positions
for iSource=1:size(sources,1)
    
    GPF=GPS*FF{iSource}; % probe to nullfilter gain    
    GG=max(abs(GPF),[],2);
    GG=reshape(GG,NNN,NNN); 
    GG=zero_outside(GG, max(GG(:))); 
    GG=log10(GG);
    [~,idx]=min((reshape(GG,NNN*NNN,1))); % --> position estimate

    drawcross(sources(iSource,:), 'g', 0.1, 1); 
    drawcross(probes(idx,:), cl(mod(iSource-1,7)+1,:), 0.02,[], 'linewidth', 4); 
    drawnow
end
hold on
plotsensors(sensors);
set(gca,'box','off')
set(get(gca,'xaxis'), 'visible','off')
set(get(gca,'yaxis'), 'visible','off')
    
