%{
Fig. 511 of WW paper.
%}
if ~check_required; return; end

addpath ../sphere_sampling

clear

% load trials locked to interictal spikes
matfiles = dir('../BST epilepsy EEG/*.mat');
try
    load(['../BST epilepsy EEG/',matfiles(1).name]); % loads D
catch ME
    disp(ME.message);
    error('cannot load files from ../BST epilepsy EEG/: path may be bad, or bst_plugin may have failed to load SPM');
end

sr=D.Fsample;
N = length(matfiles) ; 
d=zeros(size(D.data,2),size(D.data,1),N);
for i = 1:N
    load(['../BST epilepsy EEG/',matfiles(i).name]);
    x=D.data;
    d(:,:,i)=double(x)';    
end
t=linspace(-1, 0.5, size(d,1));

% select the EEG channels
idxEEG=[1:19, 23:24,30:37];
d=d(:,idxEEG,:);

% load head model prepared in Brainstorm
load ../from_bst/head_model_epilepsy_EEG_volume_2mm
loc=head_model.GridLoc;
orient=head_model.GridOrient;
g=head_model.Gain;
nlocations=size(g,2)/3;
nsensors=size(g,1);
g=g'; % --> (nlocationsX3) X nsensors
g=reshape(g,3,nlocations,nsensors);
g=permute(g,[2,3,1]);
gain3=g(:,idxEEG,:);
x=loc(:,1);
y=loc(:,2);
z=loc(:,3);

if 1
    % high-pass
    d=nt_demean2(d,t<-0.05);
    hpf=3;
    [B,A]=butter(2,hpf/(sr/2),'high');
    d=filter(B,A,d);
end

% clip to shorter interval
d=d(find(t>-0.5&t<0.2),:,:);
t=t(find(t>-0.5&t<0.2));

% DSS to maximize repeatability
d=nt_demean2(d,t<-0.05);
nt_dss1(d);
[todss,pwr0,pwr1]=nt_dss1(d);
z=nt_mmat(d,todss);

% rotate to put earliest part on first component
NDSS1=3;
z=z(:,1:NDSS1,:);
c0=nt_cov(mean(z(t>0,:,:),3)); c1=nt_cov(mean(z(t>-0.025&t<-0.01,:,:),3));
[todss2,pwr0,pwr1]=nt_dss0(c0,c1);
zz=nt_mmat(z,todss2);

% temporally align (initial alignment was manual)
idxPeak=zeros(size(d,3),1);
for iTrial=1:size(d,3)
    FOCUS=t>-0.03&t<0.01;
    a=xcorr(mean(zz(FOCUS,1,:),3),zz(FOCUS,1,iTrial));
    [~,idxPeak(iTrial)]=max(a);
end
shift=idxPeak-min(idxPeak);
shift=max(shift)-shift;
dd=zeros(size(d,1)-max(shift),size(d,2),size(d,3));
idx=1:size(dd,1);
for iTrial=1:size(d,3)
    dd(:,:,iTrial)=d(shift(iTrial)+idx,:,iTrial);
end
t=t(median(shift)+idx);

% redo DSS analyses
d=dd;

% DSS to maximize repeatability
d=nt_demean2(d,t<-0.05);
nt_dss1(d);
[todss,pwr0,pwr1]=nt_dss1(d);
z=nt_mmat(d,todss);

% rotate to put earliest part on first component
NDSS1=3;
z=z(:,1:NDSS1,:);
c0=nt_cov(mean(z(t>0,:,:),3)); c1=nt_cov(mean(z(t>-0.03&t<0,:,:),3));
[todss2,pwr0,pwr1]=nt_dss0(c0,c1);
zz=nt_mmat(z,todss2);

% null filters
F=[todss(:,1:NDSS1)*todss2, todss(:,NDSS1+1:end)]; % combine rotated components with the rest
F=nt_normcol(F);

% cost function
nTarget=1;
[~,~,~,cc]=find_source_orient(nt_mmat(gain3,F),nTarget);
cc=log10(cc);

figure(2); clf
set(gcf,'position',[200   597   1200   150])
background=[1 1 1]*1;

subplot 144
%scatter3(x,y,z,10,cc,'filled'); 
[cc_collapsed,l_collapsed]=collapse_xyz(cc,loc,1);
x=l_collapsed(:,1);
y=l_collapsed(:,2);
z=l_collapsed(:,3);
scatter3(x,y,z,10,cc_collapsed,'filled');
colormap (parula);
h=colorbar('eastoutside');
set(h,'fontsize',14);
set(get(h,'label'),'string','$log_{10}$(cost)','interpreter','latex', 'fontsize',18);
set(gca,'color',[1 1 1])
set(gca,'xtick',[],'ytick',[],'ztick',[]);
set(gca,'box','off')
set(get(gca,'xaxis'), 'visible','off')
set(get(gca,'yaxis'), 'visible','off')
set(get(gca,'zaxis'), 'visible','off')
view(-90,0)
set(gca,'clim',[-inf 0]);

subplot 143
%scatter3(x,y,z,10,cc,'filled'); 
[cc_collapsed,l_collapsed]=collapse_xyz(cc,loc,2);
x=l_collapsed(:,1);
y=l_collapsed(:,2);
z=l_collapsed(:,3);
scatter3(x,y,z,10,cc_collapsed,'filled');
colormap (parula);
set(gca,'color',[1 1 1])
set(gca,'xtick',[],'ytick',[],'ztick',[]);
set(gca,'box','off')
set(get(gca,'xaxis'), 'visible','off')
set(get(gca,'yaxis'), 'visible','off')
set(get(gca,'zaxis'), 'visible','off')
view(0,0)
set(gca,'clim',[-inf 0]);

subplot 142
%scatter3(x,y,z,10,cc,'filled'); 
[cc_collapsed,l_collapsed]=collapse_xyz(cc,loc,3);
x=l_collapsed(:,1);
y=l_collapsed(:,2);
z=l_collapsed(:,3);
scatter3(x,y,z,10,cc_collapsed,'filled');
colormap (parula);
set(gca,'color',[1 1 1])
set(gca,'xtick',[],'ytick',[],'ztick',[]);
set(gca,'box','off')
set(get(gca,'xaxis'), 'visible','off')
set(get(gca,'yaxis'), 'visible','off')
set(get(gca,'zaxis'), 'visible','off')
view(0,90)
set(gca,'clim',[-inf 0]);

subplot 141
plot(t,mean(zz,3))
set(gca,'fontsize',14);
xlim([-0.2 0.2]);
set(gca,'ytick',[]);
xlabel('time (s)'); ylabel('a.u');
legend('c1', 'c2','c3', 'location', 'eastoutside');legend boxoff;

plot_tweak([0.02, 0.15, 0 -0.15])
