Code for paper "What and where in electromagnetic brain imaging"

Running this code will require downloading several toolboxes and datasets, 
as detailed in check_required.m.  It may also require adjusting paths
and recalculating missing tmp files. Some scripts require head models for
Brainstorm tutorial datasets. These must be calculated in Brainstorm and
saved as files in ../from_bst/.

Check for toolboxes & data:
check_required.m

Figures of main paper:
Fig_W2.m
Fig_W3.m
Fig_W4.m
Fig_W5.m
Fig_w5b.m

Figures of Supplementary Information:
Fig_S2.m
Fig_S3.m
Fig_S4.m
Fig_S5.m
Fig_S6.m
Fig_S7.m
Fig_S8.m
Fig_S9.m
Fig_S10.m
Fig_S10b.m
Fig_S10c.m
Fig_S11.m
Fig_S12.m

Input data:
get_dtu_tone.m
read_brainstorm_tutorial_data.m
headmodelparse.m

Drawing:
drawcross.m
plot_SEEG_electrodes.m
plot_cost_volume.m
plotsensors.m
symlog.m
zero_outside.m
collapse_xyz.m

Source/forward model:
source_grid.m
sensor_positions.m
source2filter.m
source2sensor.m
sqdist.m
closest.m

Cost function, search:
cost_function2.m
cost_function5.m
cost_function5b.m
zerox.m
zerox3.m
find_source.m
find_source_orient.m
find_source_orient2.m
find_source_pair.m
find_source_volume.m


